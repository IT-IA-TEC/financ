/* @ds-bundle: {"format":4,"namespace":"YouNewDS_5cb4d2","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Accordion","sourcePath":"components/layout/Accordion.jsx"},{"name":"Card","sourcePath":"components/layout/Card.jsx"},{"name":"SectionHeading","sourcePath":"components/layout/SectionHeading.jsx"},{"name":"Callout","sourcePath":"components/marketing/Callout.jsx"},{"name":"PricingCard","sourcePath":"components/marketing/PricingCard.jsx"},{"name":"Quote","sourcePath":"components/marketing/Quote.jsx"},{"name":"Stat","sourcePath":"components/marketing/Stat.jsx"},{"name":"Testimonial","sourcePath":"components/marketing/Testimonial.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"857d66e56302","components/core/Button.jsx":"ad9c7eff058a","components/core/IconButton.jsx":"cb631f57cb31","components/forms/Checkbox.jsx":"8af04a53d0f8","components/forms/Input.jsx":"97339a28651e","components/forms/Radio.jsx":"0bc48f034f96","components/forms/Select.jsx":"45020a5694f6","components/forms/Switch.jsx":"3f70897ff80d","components/layout/Accordion.jsx":"16fff8352751","components/layout/Card.jsx":"dbe94ce32f99","components/layout/SectionHeading.jsx":"ac7d601feeb3","components/marketing/Callout.jsx":"aa430158fb0f","components/marketing/PricingCard.jsx":"aa1dffee2f14","components/marketing/Quote.jsx":"a7a942868837","components/marketing/Stat.jsx":"ffe1c837d245","components/marketing/Testimonial.jsx":"84c43fbb247f","ui_kits/institutional/image-slot.js":"0394ad34f685","ui_kits/institutional/instAbout.jsx":"7b9492a0448d","ui_kits/institutional/instApp.jsx":"49c94e223034","ui_kits/institutional/instContact.jsx":"f8225e2ff514","ui_kits/institutional/instFooter.jsx":"0c7f0bea750c","ui_kits/institutional/instHeader.jsx":"b47223b27099","ui_kits/institutional/instHero.jsx":"7be878edd155","ui_kits/institutional/instServices.jsx":"6ea7a743ef16","ui_kits/landing/landingApp.jsx":"b6e844c948dc","ui_kits/landing/landingFooter.jsx":"7b698b0fe304","ui_kits/landing/landingHeader.jsx":"9aa10cc83280","ui_kits/landing/landingHero.jsx":"152aedf080c5","ui_kits/landing/landingPlans.jsx":"52c87d37415d","ui_kits/landing/landingProof.jsx":"940c1d7cc4a3","ui_kits/landing/landingValue.jsx":"24a5cb0a04c8"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.YouNewDS_5cb4d2 = window.YouNewDS_5cb4d2 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const PAL = {
  brand: {
    base: 'var(--brand-orange)',
    soft: 'var(--orange-50)',
    softFg: 'var(--orange-text)',
    solidFg: 'var(--text-on-orange)'
  },
  success: {
    base: 'var(--success-500)',
    soft: 'var(--success-100)',
    softFg: 'var(--success-700)',
    solidFg: '#fff'
  },
  danger: {
    base: 'var(--danger-500)',
    soft: 'var(--danger-100)',
    softFg: 'var(--danger-700)',
    solidFg: '#fff'
  },
  neutral: {
    base: 'var(--neutral-600)',
    soft: 'var(--neutral-100)',
    softFg: 'var(--neutral-700)',
    solidFg: '#fff'
  },
  dark: {
    base: 'var(--ink)',
    soft: 'var(--neutral-100)',
    softFg: 'var(--ink)',
    solidFg: '#fff'
  },
  amber: {
    base: 'var(--amber-500)',
    soft: 'var(--amber-50)',
    softFg: 'var(--amber-800)',
    solidFg: 'var(--ink)'
  }
};

/**
 * Selo / etiqueta pequena, "CRC ativo", "Especialista em ML e Shopee", status.
 * Regra: sobre laranja o texto é ESCURO; --brand-orange-2 (amber) nunca recebe texto (cai para soft).
 */
function Badge({
  children,
  color = 'brand',
  variant = 'soft',
  size = 'md',
  pill = true,
  dot = false,
  leftIcon,
  style,
  ...rest
}) {
  let v = variant;
  if (color === 'amber' && v === 'solid') v = 'soft'; // amber nunca carrega texto em bloco cheio
  const p = PAL[color] || PAL.brand;
  let bg,
    fg,
    border = '1.5px solid transparent';
  if (v === 'solid') {
    bg = p.base;
    fg = p.solidFg;
  } else if (v === 'outline') {
    bg = 'transparent';
    fg = p.softFg;
    border = `1.5px solid ${p.base}`;
  } else {
    bg = p.soft;
    fg = p.softFg;
  }
  const S = size === 'sm' ? {
    padding: '2px 8px',
    fontSize: '11px',
    gap: '4px'
  } : {
    padding: '4px 11px',
    fontSize: '12.5px',
    gap: '5px'
  };
  const s = {
    display: 'inline-flex',
    alignItems: 'center',
    gap: S.gap,
    padding: S.padding,
    fontSize: S.fontSize,
    fontFamily: 'var(--font-sans)',
    fontWeight: 600,
    lineHeight: 1.2,
    letterSpacing: '.01em',
    background: bg,
    color: fg,
    border,
    borderRadius: pill ? 'var(--radius-pill)' : 'var(--radius-md)',
    whiteSpace: 'nowrap',
    ...style
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    style: s
  }, rest), dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: '6px',
      height: '6px',
      borderRadius: '50%',
      background: 'currentColor',
      flex: 'none'
    }
  }), leftIcon && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      fontSize: '1.05em'
    }
  }, leftIcon), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.you-btn{display:inline-flex;align-items:center;justify-content:center;font-family:var(--font-sans);font-weight:600;line-height:1;border:1.5px solid transparent;cursor:pointer;text-decoration:none;white-space:nowrap;box-sizing:border-box;user-select:none;transition:background var(--dur-base) var(--ease-out),color var(--dur-base) var(--ease-out),border-color var(--dur-base) var(--ease-out),transform var(--dur-fast) var(--ease-out)}
.you-btn:focus-visible{outline:none;box-shadow:var(--ring-focus)}
.you-btn:active{transform:translateY(1px)}
.you-btn[disabled],.you-btn.is-loading{opacity:.5;cursor:not-allowed;pointer-events:none}
.you-btn--full{display:flex;width:100%}
.you-btn--sm{padding:9px 16px;font-size:var(--fs-small);gap:7px;min-height:40px}
.you-btn--md{padding:13px 22px;font-size:var(--fs-body);gap:8px;min-height:48px}
.you-btn--lg{padding:16px 30px;font-size:var(--fs-body-lg);gap:10px;min-height:56px}
.you-btn--xl{padding:19px 38px;font-size:var(--fs-body-lg);gap:11px;min-height:62px}
.you-btn--pill{border-radius:var(--radius-pill)}
.you-btn--round{border-radius:var(--radius-md)}
.you-btn--primary{background:var(--brand-orange);color:var(--text-on-orange)}
.you-btn--primary:hover{background:var(--orange-text)}
.you-btn--secondary{background:var(--ink);color:var(--white)}
.you-btn--secondary:hover{background:var(--ink-2)}
.you-btn--outline{background:transparent;color:var(--ink);border-color:var(--border-strong)}
.you-btn--outline:hover{border-color:var(--ink);background:var(--surface)}
.you-btn--ghost{background:transparent;color:var(--text-secondary)}
.you-btn--ghost:hover{background:var(--surface-2);color:var(--ink)}
.you-btn--soft{background:var(--orange-50);color:var(--orange-text)}
.you-btn--soft:hover{background:var(--orange-100)}
.you-btn__icon{display:inline-flex;align-items:center;justify-content:center}
.you-btn__icon svg{width:1.1em;height:1.1em;display:block}
.you-btn__spin{width:1.05em;height:1.05em;border:2px solid currentColor;border-right-color:transparent;border-radius:50%;animation:you-spin .6s linear infinite}
@keyframes you-spin{to{transform:rotate(360deg)}}
`;
if (typeof document !== 'undefined' && !document.getElementById('you-btn-css')) {
  const s = document.createElement('style');
  s.id = 'you-btn-css';
  s.textContent = CSS;
  document.head.appendChild(s);
}

/**
 * Botão. `primary` = laranja sólido, texto ESCURO, pílula (a pílula é exclusiva do CTA principal).
 * Demais variantes usam raio 14px. Renderiza <a> quando `href` é passado.
 */
function Button({
  children,
  variant = 'primary',
  size = 'md',
  pill,
  fullWidth = false,
  leftIcon,
  rightIcon,
  loading = false,
  disabled = false,
  href,
  className = '',
  ...rest
}) {
  const isPill = pill === undefined ? variant === 'primary' : pill;
  const cls = ['you-btn', `you-btn--${variant}`, `you-btn--${size}`, isPill ? 'you-btn--pill' : 'you-btn--round', fullWidth ? 'you-btn--full' : '', loading ? 'is-loading' : '', className].filter(Boolean).join(' ');
  const content = /*#__PURE__*/React.createElement(React.Fragment, null, loading && /*#__PURE__*/React.createElement("span", {
    className: "you-btn__spin",
    "aria-hidden": "true"
  }), !loading && leftIcon && /*#__PURE__*/React.createElement("span", {
    className: "you-btn__icon"
  }, leftIcon), children && /*#__PURE__*/React.createElement("span", null, children), !loading && rightIcon && /*#__PURE__*/React.createElement("span", {
    className: "you-btn__icon"
  }, rightIcon));
  if (href && !disabled) return /*#__PURE__*/React.createElement("a", _extends({
    href: href,
    className: cls
  }, rest), content);
  return /*#__PURE__*/React.createElement("button", _extends({
    className: cls,
    disabled: disabled || loading
  }, rest), content);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.you-iconbtn{display:inline-flex;align-items:center;justify-content:center;border:1.5px solid transparent;cursor:pointer;box-sizing:border-box;padding:0;flex:none;transition:var(--transition-base)}
.you-iconbtn:focus-visible{outline:none;box-shadow:var(--ring-focus)}
.you-iconbtn:active{transform:translateY(1px)}
.you-iconbtn[disabled]{opacity:.5;cursor:not-allowed;pointer-events:none}
.you-iconbtn--sm{width:40px;height:40px;font-size:16px}
.you-iconbtn--md{width:48px;height:48px;font-size:18px}
.you-iconbtn--lg{width:56px;height:56px;font-size:20px}
.you-iconbtn--round{border-radius:var(--radius-circle)}
.you-iconbtn--square{border-radius:var(--radius-md)}
.you-iconbtn--primary{background:var(--brand-orange);color:var(--text-on-orange)}
.you-iconbtn--primary:hover{background:var(--orange-text)}
.you-iconbtn--soft{background:var(--orange-50);color:var(--orange-text)}
.you-iconbtn--soft:hover{background:var(--orange-100)}
.you-iconbtn--outline{background:var(--white);color:var(--ink);border-color:var(--border-strong)}
.you-iconbtn--outline:hover{border-color:var(--ink)}
.you-iconbtn--ghost{background:transparent;color:var(--text-secondary)}
.you-iconbtn--ghost:hover{background:var(--surface-2);color:var(--ink)}
.you-iconbtn svg{width:1.25em;height:1.25em;display:block}
`;
if (typeof document !== 'undefined' && !document.getElementById('you-iconbtn-css')) {
  const s = document.createElement('style');
  s.id = 'you-iconbtn-css';
  s.textContent = CSS;
  document.head.appendChild(s);
}

/** Botão só com ícone, controles de nav, fechar, redes, WhatsApp. Sempre passe `aria-label`. */
function IconButton({
  icon,
  children,
  variant = 'soft',
  size = 'md',
  round = true,
  disabled = false,
  href,
  className = '',
  ...rest
}) {
  const cls = ['you-iconbtn', `you-iconbtn--${variant}`, `you-iconbtn--${size}`, round ? 'you-iconbtn--round' : 'you-iconbtn--square', className].filter(Boolean).join(' ');
  const content = icon || children;
  if (href && !disabled) return /*#__PURE__*/React.createElement("a", _extends({
    href: href,
    className: cls
  }, rest), content);
  return /*#__PURE__*/React.createElement("button", _extends({
    className: cls,
    disabled: disabled
  }, rest), content);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.you-check{display:inline-flex;align-items:flex-start;gap:11px;cursor:pointer;font-family:var(--font-sans);position:relative}
.you-check--disabled{cursor:not-allowed;opacity:.55}
.you-check__input{position:absolute;width:1px;height:1px;opacity:0;margin:0}
.you-check__box{flex:none;width:22px;height:22px;border-radius:7px;border:2px solid var(--border-strong);background:var(--surface-card);display:inline-flex;align-items:center;justify-content:center;color:#fff;transition:var(--transition-base);margin-top:1px}
.you-check__box svg{width:15px;height:15px;opacity:0;transform:scale(.5);transition:var(--transition-base)}
.you-check__input:checked + .you-check__box{background:var(--gradient-brand);border-color:transparent}
.you-check__input:checked + .you-check__box svg{opacity:1;transform:scale(1)}
.you-check__input:focus-visible + .you-check__box{box-shadow:var(--ring-focus)}
.you-check__text{display:flex;flex-direction:column;gap:2px}
.you-check__lbl{font-size:15px;font-weight:600;color:var(--text-strong);line-height:1.35}
.you-check__desc{font-size:13px;color:var(--text-muted);line-height:1.4}
`;
if (typeof document !== 'undefined' && !document.getElementById('you-check-css')) {
  const s = document.createElement('style');
  s.id = 'you-check-css';
  s.textContent = CSS;
  document.head.appendChild(s);
}

/** Checkbox with optional label + description. Controlled (`checked`) or uncontrolled (`defaultChecked`). */
function Checkbox({
  label,
  description,
  checked,
  defaultChecked,
  onChange,
  disabled = false,
  id,
  className = '',
  ...rest
}) {
  const auto = React.useId();
  const rid = id || auto;
  const cls = ['you-check', disabled ? 'you-check--disabled' : '', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("label", {
    className: cls,
    htmlFor: rid
  }, /*#__PURE__*/React.createElement("input", _extends({
    id: rid,
    type: "checkbox",
    className: "you-check__input",
    checked: checked,
    defaultChecked: defaultChecked,
    onChange: onChange,
    disabled: disabled
  }, rest)), /*#__PURE__*/React.createElement("span", {
    className: "you-check__box",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "3.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("polyline", {
    points: "20 6 9 17 4 12"
  }))), (label || description) && /*#__PURE__*/React.createElement("span", {
    className: "you-check__text"
  }, label && /*#__PURE__*/React.createElement("span", {
    className: "you-check__lbl"
  }, label), description && /*#__PURE__*/React.createElement("span", {
    className: "you-check__desc"
  }, description)));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.you-field{display:flex;flex-direction:column;gap:7px;font-family:var(--font-sans)}
.you-field--full{width:100%}
.you-field__label{font-size:14px;font-weight:600;color:var(--text-strong)}
.you-field__wrap{display:flex;align-items:center;gap:10px;background:var(--surface-card);border:2px solid var(--border-default);border-radius:var(--radius-md);padding:0 14px;transition:var(--transition-base)}
.you-field__wrap:focus-within{border-color:var(--brand);box-shadow:var(--ring-focus)}
.you-field--error .you-field__wrap{border-color:var(--danger-500)}
.you-field--error .you-field__wrap:focus-within{box-shadow:0 0 0 4px rgba(229,53,43,.32)}
.you-field--disabled .you-field__wrap{background:var(--surface-muted);opacity:.7}
.you-input{flex:1;border:none;outline:none;background:transparent;font-family:inherit;color:var(--text-strong);width:100%;min-width:0}
.you-input::placeholder{color:var(--text-muted)}
.you-field--md .you-input{font-size:15px;padding:12px 0}
.you-field--lg .you-input{font-size:16px;padding:15px 0}
.you-field__icon{display:inline-flex;color:var(--text-muted);flex:none}
.you-field__icon svg{width:19px;height:19px}
.you-field__help{font-size:12.5px;color:var(--text-muted)}
.you-field--error .you-field__help{color:var(--danger-600);font-weight:500}
`;
if (typeof document !== 'undefined' && !document.getElementById('you-field-css')) {
  const s = document.createElement('style');
  s.id = 'you-field-css';
  s.textContent = CSS;
  document.head.appendChild(s);
}

/** Text input with label, helper/error text and optional icons. */
function Input({
  label,
  helperText,
  error,
  leftIcon,
  rightIcon,
  size = 'md',
  fullWidth = true,
  disabled = false,
  id,
  className = '',
  ...rest
}) {
  const auto = React.useId();
  const rid = id || auto;
  const isErr = !!error;
  const cls = ['you-field', `you-field--${size}`, fullWidth ? 'you-field--full' : '', isErr ? 'you-field--error' : '', disabled ? 'you-field--disabled' : '', className].filter(Boolean).join(' ');
  const msg = isErr && typeof error === 'string' ? error : helperText;
  return /*#__PURE__*/React.createElement("div", {
    className: cls
  }, label && /*#__PURE__*/React.createElement("label", {
    className: "you-field__label",
    htmlFor: rid
  }, label), /*#__PURE__*/React.createElement("div", {
    className: "you-field__wrap"
  }, leftIcon && /*#__PURE__*/React.createElement("span", {
    className: "you-field__icon"
  }, leftIcon), /*#__PURE__*/React.createElement("input", _extends({
    id: rid,
    className: "you-input",
    disabled: disabled,
    "aria-invalid": isErr || undefined
  }, rest)), rightIcon && /*#__PURE__*/React.createElement("span", {
    className: "you-field__icon"
  }, rightIcon)), msg && /*#__PURE__*/React.createElement("span", {
    className: "you-field__help"
  }, msg));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.you-radio{display:inline-flex;align-items:flex-start;gap:11px;cursor:pointer;font-family:var(--font-sans);position:relative}
.you-radio--disabled{cursor:not-allowed;opacity:.55}
.you-radio__input{position:absolute;width:1px;height:1px;opacity:0;margin:0}
.you-radio__box{flex:none;width:22px;height:22px;border-radius:50%;border:2px solid var(--border-strong);background:var(--surface-card);display:inline-flex;align-items:center;justify-content:center;transition:var(--transition-base);margin-top:1px}
.you-radio__box::after{content:'';width:9px;height:9px;border-radius:50%;background:#fff;transform:scale(0);transition:var(--transition-base)}
.you-radio__input:checked + .you-radio__box{background:var(--gradient-brand);border-color:transparent}
.you-radio__input:checked + .you-radio__box::after{transform:scale(1)}
.you-radio__input:focus-visible + .you-radio__box{box-shadow:var(--ring-focus)}
.you-radio__text{display:flex;flex-direction:column;gap:2px}
.you-radio__lbl{font-size:15px;font-weight:600;color:var(--text-strong);line-height:1.35}
.you-radio__desc{font-size:13px;color:var(--text-muted);line-height:1.4}
`;
if (typeof document !== 'undefined' && !document.getElementById('you-radio-css')) {
  const s = document.createElement('style');
  s.id = 'you-radio-css';
  s.textContent = CSS;
  document.head.appendChild(s);
}

/** Radio button. Group them by sharing the same `name`. */
function Radio({
  label,
  description,
  name,
  value,
  checked,
  defaultChecked,
  onChange,
  disabled = false,
  id,
  className = '',
  ...rest
}) {
  const auto = React.useId();
  const rid = id || auto;
  const cls = ['you-radio', disabled ? 'you-radio--disabled' : '', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("label", {
    className: cls,
    htmlFor: rid
  }, /*#__PURE__*/React.createElement("input", _extends({
    id: rid,
    type: "radio",
    className: "you-radio__input",
    name: name,
    value: value,
    checked: checked,
    defaultChecked: defaultChecked,
    onChange: onChange,
    disabled: disabled
  }, rest)), /*#__PURE__*/React.createElement("span", {
    className: "you-radio__box",
    "aria-hidden": "true"
  }), (label || description) && /*#__PURE__*/React.createElement("span", {
    className: "you-radio__text"
  }, label && /*#__PURE__*/React.createElement("span", {
    className: "you-radio__lbl"
  }, label), description && /*#__PURE__*/React.createElement("span", {
    className: "you-radio__desc"
  }, description)));
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.you-select{appearance:none;-webkit-appearance:none;flex:1;border:none;outline:none;background:transparent;font-family:inherit;color:var(--text-strong);width:100%;min-width:0;cursor:pointer}
.you-field--md .you-select{font-size:15px;padding:12px 0}
.you-field--lg .you-select{font-size:16px;padding:15px 0}
.you-select__chev{color:var(--text-muted);flex:none;display:inline-flex;pointer-events:none}
.you-select__chev svg{width:20px;height:20px}
.you-select:disabled{cursor:not-allowed}
`;
if (typeof document !== 'undefined' && !document.getElementById('you-select-css')) {
  const s = document.createElement('style');
  s.id = 'you-select-css';
  s.textContent = CSS;
  document.head.appendChild(s);
}

/** Native <select> styled to match Input, with a chevron. Pass `options` or `children`. */
function Select({
  label,
  helperText,
  error,
  options,
  children,
  placeholder,
  size = 'md',
  fullWidth = true,
  disabled = false,
  id,
  className = '',
  ...rest
}) {
  const auto = React.useId();
  const rid = id || auto;
  const isErr = !!error;
  const cls = ['you-field', `you-field--${size}`, fullWidth ? 'you-field--full' : '', isErr ? 'you-field--error' : '', disabled ? 'you-field--disabled' : '', className].filter(Boolean).join(' ');
  const msg = isErr && typeof error === 'string' ? error : helperText;
  const opts = options && options.map(o => typeof o === 'string' ? /*#__PURE__*/React.createElement("option", {
    key: o,
    value: o
  }, o) : /*#__PURE__*/React.createElement("option", {
    key: o.value,
    value: o.value
  }, o.label));
  return /*#__PURE__*/React.createElement("div", {
    className: cls
  }, label && /*#__PURE__*/React.createElement("label", {
    className: "you-field__label",
    htmlFor: rid
  }, label), /*#__PURE__*/React.createElement("div", {
    className: "you-field__wrap"
  }, /*#__PURE__*/React.createElement("select", _extends({
    id: rid,
    className: "you-select",
    disabled: disabled,
    defaultValue: placeholder ? '' : undefined,
    "aria-invalid": isErr || undefined
  }, rest), placeholder && /*#__PURE__*/React.createElement("option", {
    value: "",
    disabled: true
  }, placeholder), opts || children), /*#__PURE__*/React.createElement("span", {
    className: "you-select__chev",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("polyline", {
    points: "6 9 12 15 18 9"
  })))), msg && /*#__PURE__*/React.createElement("span", {
    className: "you-field__help"
  }, msg));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.you-switch{display:inline-flex;align-items:center;gap:11px;cursor:pointer;font-family:var(--font-sans)}
.you-switch--disabled{cursor:not-allowed;opacity:.55}
.you-switch__input{position:absolute;width:1px;height:1px;opacity:0;margin:0}
.you-switch__track{flex:none;width:46px;height:27px;border-radius:var(--radius-pill);background:var(--neutral-300);position:relative;transition:var(--transition-base)}
.you-switch__track::after{content:'';position:absolute;top:3px;left:3px;width:21px;height:21px;border-radius:50%;background:#fff;box-shadow:var(--shadow-sm);transition:transform var(--dur-base) var(--ease-spring)}
.you-switch__input:checked + .you-switch__track{background:var(--gradient-brand)}
.you-switch__input:checked + .you-switch__track::after{transform:translateX(19px)}
.you-switch__input:focus-visible + .you-switch__track{box-shadow:var(--ring-focus)}
.you-switch--sm .you-switch__track{width:38px;height:22px}
.you-switch--sm .you-switch__track::after{width:16px;height:16px}
.you-switch--sm .you-switch__input:checked + .you-switch__track::after{transform:translateX(16px)}
.you-switch__lbl{font-size:15px;font-weight:600;color:var(--text-strong)}
`;
if (typeof document !== 'undefined' && !document.getElementById('you-switch-css')) {
  const s = document.createElement('style');
  s.id = 'you-switch-css';
  s.textContent = CSS;
  document.head.appendChild(s);
}

/** On/off toggle. Controlled (`checked`) or uncontrolled (`defaultChecked`). */
function Switch({
  label,
  checked,
  defaultChecked,
  onChange,
  disabled = false,
  size = 'md',
  id,
  className = '',
  ...rest
}) {
  const auto = React.useId();
  const rid = id || auto;
  const cls = ['you-switch', `you-switch--${size}`, disabled ? 'you-switch--disabled' : '', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("label", {
    className: cls,
    htmlFor: rid
  }, /*#__PURE__*/React.createElement("input", _extends({
    id: rid,
    type: "checkbox",
    role: "switch",
    className: "you-switch__input",
    checked: checked,
    defaultChecked: defaultChecked,
    onChange: onChange,
    disabled: disabled
  }, rest)), /*#__PURE__*/React.createElement("span", {
    className: "you-switch__track",
    "aria-hidden": "true"
  }), label && /*#__PURE__*/React.createElement("span", {
    className: "you-switch__lbl"
  }, label));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/layout/Accordion.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.you-acc{display:flex;flex-direction:column;gap:12px}
.you-acc__item{border:1.5px solid var(--border-subtle);border-radius:var(--radius-md);background:var(--surface-card);transition:border-color var(--dur-base) var(--ease-out),box-shadow var(--dur-base) var(--ease-out)}
.you-acc__item.open{border-color:var(--brand);box-shadow:var(--shadow-sm)}
.you-acc__head{width:100%;display:flex;align-items:center;justify-content:space-between;gap:16px;padding:18px 22px;background:none;border:none;cursor:pointer;font-family:var(--font-sans);font-weight:700;font-size:16px;color:var(--text-strong);text-align:left;border-radius:var(--radius-md)}
.you-acc__head:focus-visible{outline:none;box-shadow:var(--ring-focus)}
.you-acc__chev{flex:none;width:34px;height:34px;border-radius:50%;background:var(--brand-orange);color:var(--text-on-orange);display:grid;place-items:center;transition:transform var(--dur-base) var(--ease-out)}
.you-acc__item.open .you-acc__chev{transform:rotate(180deg)}
.you-acc__chev svg{width:18px;height:18px;display:block}
.you-acc__panel{display:grid;grid-template-rows:0fr;transition:grid-template-rows var(--dur-slow) var(--ease-out)}
.you-acc__item.open .you-acc__panel{grid-template-rows:1fr}
.you-acc__inner{overflow:hidden}
.you-acc__body{padding:0 22px 20px;color:var(--text-body);font-size:15px;line-height:1.6}
`;
if (typeof document !== 'undefined' && !document.getElementById('you-acc-css')) {
  const s = document.createElement('style');
  s.id = 'you-acc-css';
  s.textContent = CSS;
  document.head.appendChild(s);
}

/** FAQ accordion. Pass `items` of {question, answer}. Smoothly expands via grid-rows. */
function Accordion({
  items = [],
  allowMultiple = false,
  defaultOpen = [],
  className = '',
  ...rest
}) {
  const [open, setOpen] = React.useState(() => new Set(defaultOpen));
  const toggle = i => setOpen(prev => {
    const n = new Set(prev);
    if (n.has(i)) n.delete(i);else {
      if (!allowMultiple) n.clear();
      n.add(i);
    }
    return n;
  });
  return /*#__PURE__*/React.createElement("div", _extends({
    className: ['you-acc', className].filter(Boolean).join(' ')
  }, rest), items.map((it, i) => {
    const isOpen = open.has(i);
    return /*#__PURE__*/React.createElement("div", {
      className: 'you-acc__item' + (isOpen ? ' open' : ''),
      key: i
    }, /*#__PURE__*/React.createElement("button", {
      className: "you-acc__head",
      "aria-expanded": isOpen,
      onClick: () => toggle(i)
    }, /*#__PURE__*/React.createElement("span", null, it.question), /*#__PURE__*/React.createElement("span", {
      className: "you-acc__chev",
      "aria-hidden": "true"
    }, /*#__PURE__*/React.createElement("svg", {
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: "2.5",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }, /*#__PURE__*/React.createElement("polyline", {
      points: "6 9 12 15 18 9"
    })))), /*#__PURE__*/React.createElement("div", {
      className: "you-acc__panel"
    }, /*#__PURE__*/React.createElement("div", {
      className: "you-acc__inner"
    }, /*#__PURE__*/React.createElement("div", {
      className: "you-acc__body"
    }, it.answer))));
  }));
}
Object.assign(__ds_scope, { Accordion });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/Accordion.jsx", error: String((e && e.message) || e) }); }

// components/layout/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.you-card{background:var(--surface-card);border-radius:var(--radius-lg);border:1.5px solid transparent;transition:var(--transition-base);box-sizing:border-box}
.you-card--elevated{box-shadow:var(--shadow-md)}
.you-card--outline{border-color:var(--border-subtle)}
.you-card--soft{background:var(--brand-subtle)}
.you-card--muted{background:var(--surface-subtle)}
.you-card--dark{background:var(--gradient-dark);color:var(--text-on-dark)}
.you-card--gradient{background:var(--gradient-brand);color:#fff}
.you-card--pad-none{padding:0}
.you-card--pad-sm{padding:var(--space-4)}
.you-card--pad-md{padding:var(--space-6)}
.you-card--pad-lg{padding:var(--space-8)}
.you-card--hover{cursor:pointer}
.you-card--hover:hover{transform:translateY(-4px);box-shadow:var(--shadow-lg)}
.you-card--gradient.you-card--hover:hover,.you-card--dark.you-card--hover:hover{box-shadow:var(--shadow-brand-lg)}
`;
if (typeof document !== 'undefined' && !document.getElementById('you-card-css')) {
  const s = document.createElement('style');
  s.id = 'you-card-css';
  s.textContent = CSS;
  document.head.appendChild(s);
}

/** Flexible surface container, benefit cards, feature tiles, panels. */
function Card({
  children,
  variant = 'elevated',
  padding = 'md',
  hoverable = false,
  as = 'div',
  className = '',
  ...rest
}) {
  const Tag = as;
  const cls = ['you-card', `you-card--${variant}`, `you-card--pad-${padding}`, hoverable ? 'you-card--hover' : '', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement(Tag, _extends({
    className: cls
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/Card.jsx", error: String((e && e.message) || e) }); }

// components/layout/SectionHeading.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.you-sechead{display:flex;flex-direction:column;gap:14px;max-width:640px}
.you-sechead--center{align-items:center;text-align:center;margin-left:auto;margin-right:auto}
.you-sechead__eyebrow{font-size:13px;font-weight:800;letter-spacing:var(--tracking-widest);text-transform:uppercase;color:var(--brand)}
.you-sechead__title{font-family:var(--font-display);font-weight:800;font-size:var(--display-md);line-height:1.1;letter-spacing:var(--tracking-tight);color:var(--text-strong);margin:0}
.you-sechead__title em{font-style:normal;background:var(--brand-gradient);-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;color:transparent}
.you-sechead__sub{font-size:var(--text-lg);line-height:1.55;color:var(--text-muted);margin:0}
.you-sechead--on-dark .you-sechead__title{color:#fff}
.you-sechead--on-dark .you-sechead__title em{-webkit-text-fill-color:transparent}
.you-sechead--on-dark .you-sechead__sub{color:var(--neutral-300)}
.you-sechead--on-dark .you-sechead__eyebrow{color:var(--accent)}
`;
if (typeof document !== 'undefined' && !document.getElementById('you-sechead-css')) {
  const s = document.createElement('style');
  s.id = 'you-sechead-css';
  s.textContent = CSS;
  document.head.appendChild(s);
}

/** Eyebrow + title + subtitle block that opens every section. Wrap a word in <em> to highlight it orange. */
function SectionHeading({
  eyebrow,
  title,
  subtitle,
  align = 'center',
  onDark = false,
  as = 'h2',
  className = '',
  ...rest
}) {
  const Tag = as;
  const cls = ['you-sechead', align === 'center' ? 'you-sechead--center' : '', onDark ? 'you-sechead--on-dark' : '', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cls
  }, rest), eyebrow && /*#__PURE__*/React.createElement("span", {
    className: "you-sechead__eyebrow"
  }, eyebrow), /*#__PURE__*/React.createElement(Tag, {
    className: "you-sechead__title"
  }, title), subtitle && /*#__PURE__*/React.createElement("p", {
    className: "you-sechead__sub"
  }, subtitle));
}
Object.assign(__ds_scope, { SectionHeading });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/SectionHeading.jsx", error: String((e && e.message) || e) }); }

// components/marketing/Callout.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  brand: {
    bg: 'var(--brand-subtle)',
    bd: 'var(--orange-200)',
    ic: 'var(--brand)',
    ti: 'var(--orange-800)'
  },
  success: {
    bg: 'var(--success-100)',
    bd: '#A7E8C4',
    ic: 'var(--success-600)',
    ti: 'var(--success-700)'
  },
  warning: {
    bg: 'var(--warning-100)',
    bd: 'var(--amber-200)',
    ic: 'var(--warning-700)',
    ti: 'var(--amber-800)'
  },
  info: {
    bg: 'var(--info-100)',
    bd: '#B6D3F7',
    ic: 'var(--info-500)',
    ti: '#1B57A8'
  },
  dark: {
    bg: 'var(--gradient-dark)',
    bd: 'transparent',
    ic: 'var(--accent)',
    ti: '#fff'
  }
};

/** Highlighted note box, guarantees, urgency, tips. Icon + optional title + body. */
function Callout({
  tone = 'brand',
  icon,
  title,
  children,
  className = '',
  style,
  ...rest
}) {
  const t = TONES[tone] || TONES.brand;
  const dark = tone === 'dark';
  const wrap = {
    display: 'flex',
    gap: '14px',
    alignItems: 'flex-start',
    background: t.bg,
    border: `1.5px solid ${t.bd}`,
    borderRadius: 'var(--radius-lg)',
    padding: '18px 20px',
    fontFamily: 'var(--font-sans)',
    ...style
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    className: className,
    style: wrap
  }, rest), icon && /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 'none',
      color: t.ic,
      display: 'inline-flex',
      marginTop: '1px'
    }
  }, icon), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '3px'
    }
  }, title && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: '16px',
      color: dark ? '#fff' : t.ti
    }
  }, title), children && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '14.5px',
      lineHeight: 1.55,
      color: dark ? 'var(--neutral-300)' : 'var(--text-body)'
    }
  }, children)));
}
Object.assign(__ds_scope, { Callout });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/Callout.jsx", error: String((e && e.message) || e) }); }

// components/marketing/PricingCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.you-price{position:relative;display:flex;flex-direction:column;background:var(--surface-card);border:1.5px solid var(--border);border-radius:var(--radius-md);padding:var(--space-6);box-shadow:var(--shadow-sm);transition:var(--transition-base)}
.you-price--featured{border-color:var(--brand-orange);box-shadow:var(--shadow-lg)}
.you-price__ribbon{position:absolute;top:0;right:24px;transform:translateY(-50%);background:var(--brand-orange);color:var(--text-on-orange);font-size:12px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;padding:6px 14px;border-radius:var(--radius-pill)}
.you-price__name{font-family:var(--font-display);font-size:19px;font-weight:700;color:var(--text-strong);margin:0 0 6px}
.you-price__desc{font-size:14px;color:var(--text-muted);margin:0 0 18px;line-height:1.5}
.you-price__old{font-size:15px;color:var(--text-muted);text-decoration:line-through}
.you-price__amount{display:flex;align-items:baseline;gap:5px}
.you-price__cur{font-family:var(--font-display);font-size:22px;font-weight:700;color:var(--text-strong)}
.you-price__val{font-family:var(--font-display);font-size:52px;font-weight:700;line-height:1;letter-spacing:-.02em;font-variant-numeric:tabular-nums;background:var(--brand-gradient);-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;color:transparent}
.you-price__per{font-size:15px;color:var(--text-muted);font-weight:600}
.you-price__feats{list-style:none;margin:22px 0 26px;padding:0;display:flex;flex-direction:column;gap:12px}
.you-price__feat{display:flex;align-items:flex-start;gap:10px;font-size:14.5px;color:var(--text-body);line-height:1.45}
.you-price__check{flex:none;width:22px;height:22px;border-radius:50%;background:var(--success-100);color:var(--success-600);display:grid;place-items:center;margin-top:1px}
.you-price__check svg{width:14px;height:14px}
.you-price__cta{margin-top:auto}
`;
if (typeof document !== 'undefined' && !document.getElementById('you-price-css')) {
  const s = document.createElement('style');
  s.id = 'you-price-css';
  s.textContent = CSS;
  document.head.appendChild(s);
}

/** Pricing plan card. Set `featured` for the highlighted, most-popular plan. Composes <Button> for the CTA. */
function PricingCard({
  name,
  price,
  currency = 'R$',
  period = '/mês',
  oldPrice,
  description,
  features = [],
  ctaLabel = 'Quero esse plano',
  ctaProps = {},
  featured = false,
  badge = 'Mais popular',
  className = '',
  ...rest
}) {
  const cls = ['you-price', featured ? 'you-price--featured' : '', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cls
  }, rest), featured && /*#__PURE__*/React.createElement("span", {
    className: "you-price__ribbon"
  }, badge), /*#__PURE__*/React.createElement("h3", {
    className: "you-price__name"
  }, name), description && /*#__PURE__*/React.createElement("p", {
    className: "you-price__desc"
  }, description), oldPrice && /*#__PURE__*/React.createElement("div", {
    className: "you-price__old"
  }, currency, " ", oldPrice), /*#__PURE__*/React.createElement("div", {
    className: "you-price__amount"
  }, /*#__PURE__*/React.createElement("span", {
    className: "you-price__cur"
  }, currency), /*#__PURE__*/React.createElement("span", {
    className: "you-price__val"
  }, price), /*#__PURE__*/React.createElement("span", {
    className: "you-price__per"
  }, period)), /*#__PURE__*/React.createElement("ul", {
    className: "you-price__feats"
  }, features.map((f, i) => /*#__PURE__*/React.createElement("li", {
    className: "you-price__feat",
    key: i
  }, /*#__PURE__*/React.createElement("span", {
    className: "you-price__check",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "3.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("polyline", {
    points: "20 6 9 17 4 12"
  }))), /*#__PURE__*/React.createElement("span", null, f)))), /*#__PURE__*/React.createElement("div", {
    className: "you-price__cta"
  }, /*#__PURE__*/React.createElement(__ds_scope.Button, _extends({
    variant: featured ? 'primary' : 'outline',
    size: "lg",
    fullWidth: true
  }, ctaProps), ctaLabel)));
}
Object.assign(__ds_scope, { PricingCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/PricingCard.jsx", error: String((e && e.message) || e) }); }

// components/marketing/Quote.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Bloco de citação / destaque. `tone="orange"` (fundo laranja, texto escuro) ou
 * `tone="ink"` (fundo escuro, texto branco). Use dois lado a lado. Atribuição opcional.
 */
function Quote({
  children,
  tone = 'orange',
  name,
  role,
  className = '',
  style,
  ...rest
}) {
  const dark = tone === 'ink';
  const wrap = {
    display: 'flex',
    flexDirection: 'column',
    gap: '18px',
    background: dark ? 'var(--ink)' : 'var(--brand-orange)',
    color: dark ? 'var(--white)' : 'var(--text-on-orange)',
    borderRadius: 'var(--radius-md)',
    padding: 'clamp(24px,3vw,34px)',
    height: '100%',
    boxSizing: 'border-box',
    ...style
  };
  const mark = {
    fontFamily: 'var(--font-display)',
    fontWeight: 700,
    fontSize: '44px',
    lineHeight: .6,
    color: dark ? 'var(--brand-orange-2)' : 'var(--ink)',
    opacity: dark ? 1 : .5
  };
  const q = {
    fontFamily: 'var(--font-display)',
    fontWeight: 600,
    fontSize: 'var(--fs-h3)',
    lineHeight: 1.25,
    letterSpacing: '-.01em',
    margin: 0,
    flex: 1
  };
  return /*#__PURE__*/React.createElement("figure", _extends({
    className: className,
    style: wrap
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: mark,
    "aria-hidden": "true"
  }, "\u201C"), /*#__PURE__*/React.createElement("blockquote", {
    style: q
  }, children), (name || role) && /*#__PURE__*/React.createElement("figcaption", {
    style: {
      fontSize: 'var(--fs-small)',
      lineHeight: 1.35
    }
  }, name && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      fontWeight: 700
    }
  }, name), role && /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: dark ? .6 : .7
    }
  }, role)));
}
Object.assign(__ds_scope, { Quote });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/Quote.jsx", error: String((e && e.message) || e) }); }

// components/marketing/Stat.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.you-stat{display:flex;flex-direction:column;gap:6px}
.you-stat--center{align-items:center;text-align:center}
.you-stat__val{font-family:var(--font-display);font-weight:700;font-size:var(--fs-h1);line-height:1;letter-spacing:var(--ls-display);font-variant-numeric:tabular-nums;background:var(--brand-gradient);-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;color:transparent}
.you-stat--xl .you-stat__val{font-size:var(--fs-number)}
.you-stat--sm .you-stat__val{font-size:var(--fs-h2)}
.you-stat__label{font-size:var(--fs-body);color:var(--text-muted);font-weight:500;line-height:1.35;max-width:24ch}
.you-stat--center .you-stat__label{margin-inline:auto}
.you-stat--on-dark .you-stat__label{color:var(--neutral-400)}
`;
if (typeof document !== 'undefined' && !document.getElementById('you-stat-css')) {
  const s = document.createElement('style');
  s.id = 'you-stat-css';
  s.textContent = CSS;
  document.head.appendChild(s);
}

/** Número de destaque, Clash 700 em degradê laranja (background-clip:text). Valor como espaço neutro. */
function Stat({
  value,
  label,
  align = 'left',
  size = 'md',
  onDark = false,
  className = '',
  ...rest
}) {
  const cls = ['you-stat', `you-stat--${size}`, align === 'center' ? 'you-stat--center' : '', onDark ? 'you-stat--on-dark' : '', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cls
  }, rest), /*#__PURE__*/React.createElement("span", {
    className: "you-stat__val"
  }, value), /*#__PURE__*/React.createElement("span", {
    className: "you-stat__label"
  }, label));
}
Object.assign(__ds_scope, { Stat });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/Stat.jsx", error: String((e && e.message) || e) }); }

// components/marketing/Testimonial.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const STAR = 'M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.12 2.12 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.12 2.12 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.12 2.12 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.12 2.12 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.12 2.12 0 0 0 1.597-1.16z';
const CSS = `
.you-testi{display:flex;flex-direction:column;gap:16px;background:var(--surface-card);border:1.5px solid var(--border-subtle);border-radius:var(--radius-lg);padding:var(--space-6);box-shadow:var(--shadow-sm);margin:0;height:100%;box-sizing:border-box}
.you-testi__stars{display:flex;gap:2px;color:var(--amber-500)}
.you-testi__stars svg{width:18px;height:18px}
.you-testi__quote{font-size:16px;line-height:1.6;color:var(--text-body);margin:0;font-weight:500}
.you-testi__author{display:flex;align-items:center;gap:12px;margin-top:auto}
.you-testi__avatar{width:46px;height:46px;border-radius:50%;object-fit:cover;flex:none;background:var(--gradient-brand);color:#fff;display:grid;place-items:center;font-weight:800;font-family:var(--font-display);font-size:16px}
.you-testi__meta{display:flex;flex-direction:column;line-height:1.25}
.you-testi__name{font-weight:700;color:var(--text-strong);font-size:15px}
.you-testi__role{font-size:13px;color:var(--text-muted)}
`;
if (typeof document !== 'undefined' && !document.getElementById('you-testi-css')) {
  const s = document.createElement('style');
  s.id = 'you-testi-css';
  s.textContent = CSS;
  document.head.appendChild(s);
}

/** Customer testimonial card with star rating and author. Falls back to initials when no avatar. */
function Testimonial({
  quote,
  name,
  role,
  avatar,
  rating = 5,
  className = '',
  ...rest
}) {
  const initials = (name || '').split(' ').slice(0, 2).map(s => s[0]).join('').toUpperCase();
  return /*#__PURE__*/React.createElement("figure", _extends({
    className: ['you-testi', className].filter(Boolean).join(' ')
  }, rest), rating > 0 && /*#__PURE__*/React.createElement("div", {
    className: "you-testi__stars",
    "aria-label": `${rating} de 5 estrelas`
  }, Array.from({
    length: 5
  }).map((_, i) => /*#__PURE__*/React.createElement("svg", {
    key: i,
    viewBox: "0 0 24 24",
    fill: i < rating ? 'currentColor' : 'none',
    stroke: "currentColor",
    strokeWidth: "1.5"
  }, /*#__PURE__*/React.createElement("path", {
    d: STAR
  })))), /*#__PURE__*/React.createElement("blockquote", {
    className: "you-testi__quote"
  }, quote), /*#__PURE__*/React.createElement("figcaption", {
    className: "you-testi__author"
  }, avatar ? /*#__PURE__*/React.createElement("img", {
    className: "you-testi__avatar",
    src: avatar,
    alt: name
  }) : /*#__PURE__*/React.createElement("span", {
    className: "you-testi__avatar",
    "aria-hidden": "true"
  }, initials), /*#__PURE__*/React.createElement("span", {
    className: "you-testi__meta"
  }, /*#__PURE__*/React.createElement("span", {
    className: "you-testi__name"
  }, name), /*#__PURE__*/React.createElement("span", {
    className: "you-testi__role"
  }, role))));
}
Object.assign(__ds_scope, { Testimonial });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/Testimonial.jsx", error: String((e && e.message) || e) }); }

// ui_kits/institutional/image-slot.js
try { (() => {
// @ds-adherence-ignore -- omelette starter scaffold (raw elements/hex/px by design)
// Copied omelette starter. Re-running copy_starter_component with this kind overwrites this file with the latest version (page content is unaffected).
/* BEGIN USAGE */
/**
 * <image-slot> — user-fillable image placeholder.
 *
 * Drop this into a deck, mockup, or page wherever a design needs an image.
 * You control the slot's shape; it sizes to its container by default. When the search_stock_photos tool
 * is available, prefill the slot by default — write the photo's URL into
 * src (with credit/credit-href); the user can still fill or replace it
 * by dragging an image file onto it (or clicking to browse). The dropped
 * image persists across reloads via a .image-slots.state.json sidecar —
 * same read-via-fetch / write-via-window.omelette pattern as
 * design_canvas.jsx, so the filled slot shows on share links, downloaded
 * zips, and PPTX export. Outside the omelette runtime the slot is read-only.
 *
 * The sidecar is a SIBLING of the HTML file that uses this component: the
 * read is a document-relative fetch, and the host resolves the bridge's
 * sidecar writes into the previewed file's directory to match (same
 * contract as design_canvas.jsx). Pages in the same directory share one
 * sidecar; keep slot ids distinct across them.
 *
 * Attributes:
 *   id           Persistence key. REQUIRED for the drop to survive reload —
 *                every slot on the page needs a distinct id.
 *   shape        'rect' | 'rounded' | 'circle' | 'pill'   (default 'rounded')
 *                'circle' applies 50% border-radius; on a non-square slot
 *                that's an ellipse — set equal width and height for a true
 *                circle.
 *   radius       Corner radius in px for 'rounded'.       (default 12)
 *   mask         Any CSS clip-path value. Overrides `shape` — use this for
 *                hexagons, blobs, arbitrary polygons.
 *   fit          Initial framing baseline: cover | contain.   (default 'cover')
 *                cover starts the image filling the frame (overflow cropped);
 *                contain starts it fully visible (letterboxed). Either way the
 *                user can always pan/scale from there — double-click, or the
 *                Edit control, enters reframe mode (drag to move, scroll or
 *                corner-handles to scale; Escape / click-out commits). The
 *                crop persists alongside the image in the sidecar.
 *   placeholder  Empty-state caption.                      (default 'Drop an image')
 *   src          Optional initial/fallback image URL. Prefill it with a real
 *                photo via search_stock_photos when that tool is available
 *                (set credit/credit-href from the result). A user drop
 *                overrides it; clearing the drop reveals src again.
 *   credit       Attribution text shown as a small overlay at the
 *                bottom-left of the filled slot. REQUIRED whenever src
 *                points at any Unsplash host (images.unsplash.com,
 *                plus.unsplash.com, …): an Unsplash src with no credit
 *                renders an error tile INSTEAD of the photo (Unsplash
 *                terms forbid showing their photos unattributed). Use the
 *                exact form 'Photo by {photographer name} on Unsplash' —
 *                the overlay then links the name to credit-href and
 *                'Unsplash' to the Unsplash homepage, and links back to
 *                unsplash.com automatically get the required utm referral
 *                params appended at render time. The credit belongs to
 *                the src image, so it only shows while src is what's
 *                displayed — a user-dropped image hides it.
 *   credit-href  Link for the photographer's name in the credit overlay
 *                (their Unsplash profile URL from the stock-photo search
 *                results). http(s) URLs only — anything else renders the
 *                name as plain text.
 *
 * Sizing: the slot fills its container by default (width/height 100%).
 * Put it in a sized wrapper — absolutely positioned, a grid cell, a fixed
 * frame — and it takes exactly that box. When the parent's height is
 * indefinite (ordinary flow), it falls back to full width at a 3:2 aspect
 * ratio instead of collapsing. In a shrink-to-fit parent (a float,
 * width:max-content, an unsized absolute wrapper), percentages have
 * nothing to resolve against — size the slot or its wrapper explicitly
 * there. For a fixed-size slot, set
 * width/height on the element itself (inline style), which overrides the
 * default. When
 * layering content above a slot (full-bleed layouts), make the overlay
 * click-through — pointer-events: none on scrims/text plates, re-enabled
 * on interactive children — so the slot's hover controls stay reachable.
 * Keep the slot's bottom-left corner visually clear as well: the credit
 * overlay renders there, and a dark fade or text plate covering it hides
 * the attribution Unsplash's terms require — end the fade above that
 * corner, or keep it nearly transparent where the credit sits.
 *
 * Usage:
 *   <div style="position:relative;width:100%;height:100%">      <!-- full-bleed: -->
 *     <image-slot id="bg" shape="rect"></image-slot>            <!-- fills the wrapper -->
 *   </div>
 *   <image-slot id="hero"   style="width:800px;height:450px" shape="rounded" radius="20"
 *               placeholder="Drop a hero image"></image-slot>
 *   <image-slot id="avatar" style="width:120px;height:120px" shape="circle"></image-slot>
 *   <image-slot id="kite"   style="width:300px;height:300px"
 *               mask="polygon(50% 0, 100% 50%, 50% 100%, 0 50%)"></image-slot>
 */
/* END USAGE */

(() => {
  const STATE_FILE = '.image-slots.state.json';

  // Unsplash terms require visible attribution wherever their photos
  // display, and every link back to unsplash.com must carry utm referral
  // params. Two render-time rules enforce that here:
  //  - an Unsplash-src slot with NO credit attribute renders an error
  //    tile INSTEAD of the photo (an uncredited Unsplash photo on screen
  //    is itself the terms violation, so it never renders bare);
  //  - rendered credit links pointing at unsplash.com get the referral
  //    params appended when absent (credit-href values live in page
  //    content that can't be edited after the fact).
  // Keep the utm_source value in sync with UTM_SOURCE in
  // platform/web-agent/unsplash.ts — this file is a project-local
  // artifact and cannot import it (equality is pinned by tests).
  const UNSPLASH_HOMEPAGE_HREF = 'https://unsplash.com/?utm_source=claude_design&utm_medium=referral';
  // Host rule mirrors the hotlink validator that admits Unsplash srcs into
  // pages in the first place (cdn$ in unsplash.ts: apex or any subdomain)
  // — Unsplash+ results serve from plus.unsplash.com, not just images.*,
  // and an admitted-but-uncredited photo must error whatever unsplash
  // host it rides on.
  // Trailing-dot FQDNs (images.unsplash.com.) are the same host to the
  // browser but would miss the regex — strip one dot so the check fails
  // CLOSED (unrecognized-but-real Unsplash srcs must error, not render).
  const isUnsplashHost = u => {
    try {
      return /(^|\.)unsplash\.com$/.test(new URL(u, document.baseURI).hostname.replace(/\.$/, ''));
    } catch {
      return false;
    }
  };
  // Render-time referral normalization for links back to Unsplash:
  // appends utm_source/utm_medium when absent, preserves every existing
  // query param, never overwrites an existing utm_source, and passes
  // non-Unsplash URLs through untouched. Input is an ABSOLUTE validated
  // http(s) URL (the credit render funnel resolves + validates first).
  const withReferral = href => {
    try {
      const u = new URL(href);
      if (!/(^|\.)unsplash\.com$/.test(u.hostname.replace(/\.$/, ''))) {
        return href;
      }
      if (!u.searchParams.has('utm_source')) {
        u.searchParams.set('utm_source', 'claude_design');
      }
      if (!u.searchParams.has('utm_medium')) {
        u.searchParams.set('utm_medium', 'referral');
      }
      return u.toString();
    } catch (e) {
      return href;
    }
  };
  // 2× a ~600px slot in a 1920-wide deck — retina-sharp without making the
  // sidecar enormous. A 1200px WebP at q=0.85 is ~150-300KB.
  const MAX_DIM = 1200;
  // Raster formats only. SVG is excluded (can carry script; createImageBitmap
  // on SVG blobs is inconsistent). GIF is excluded because the canvas
  // re-encode keeps only the first frame, so an animated GIF would silently
  // go still — better to reject than surprise.
  const ACCEPT = ['image/png', 'image/jpeg', 'image/webp', 'image/avif'];

  // ── Shared sidecar store ────────────────────────────────────────────────
  // One fetch + immediate write-on-change for every <image-slot> on the
  // page. Reads via fetch() so viewing works anywhere the HTML and sidecar
  // are served together; writes go through window.omelette.writeFile, which
  // the host allowlists to *.state.json basenames only.
  const subs = new Set();
  let slots = {};
  // ids explicitly cleared before the sidecar fetch resolved — otherwise
  // the merge below can't tell "never set" from "just deleted" and would
  // resurrect the sidecar's stale value.
  const tombstones = new Set();
  let loaded = false;
  let loadP = null;
  function load() {
    if (loadP) return loadP;
    loadP = fetch(STATE_FILE).then(r => r.ok ? r.json() : null).then(j => {
      // Merge: sidecar loses to any in-memory change that raced ahead of
      // the fetch (drop or clear) so neither is clobbered by hydration.
      if (j && typeof j === 'object') {
        const merged = Object.assign({}, j, slots);
        // A framing-only write that raced ahead of hydration must not
        // drop a user image that's only on disk — inherit u from the
        // sidecar for any in-memory entry that lacks one.
        for (const k in slots) {
          if (merged[k] && !merged[k].u && j[k]) {
            merged[k].u = typeof j[k] === 'string' ? j[k] : j[k].u;
          }
        }
        for (const id of tombstones) delete merged[id];
        slots = merged;
      }
      tombstones.clear();
    }).catch(() => {}).then(() => {
      loaded = true;
      subs.forEach(fn => fn());
    });
    return loadP;
  }

  // Serialize writes so two near-simultaneous drops on different slots
  // can't reorder at the backend and leave the sidecar with only the
  // first. A save requested mid-flight just marks dirty and re-fires on
  // completion with the then-current slots.
  let saving = false;
  let saveDirty = false;
  // Unload-time flush: save()'s serialization defers a mid-RTT re-fire to a
  // .then that never runs in an unloading document, silently dropping a
  // pagehide commit. Post the current slots immediately instead — content
  // is a superset snapshot of any in-flight save's, the write is a
  // whole-file last-writer-wins replace, and postMessage FIFO delivers it
  // to the host after the in-flight one, so a backend-side reorder at
  // worst reproduces the dropped-commit outcome this flush improves on.
  // Guarded on the initial sidecar read: pre-hydration slots can miss
  // other slots' persisted entries, and flushing it would clobber them —
  // that narrow case stays best-effort (the in-memory merge in load()
  // cannot happen in an unloading document anyway).
  function flushNow() {
    if (!loaded) return;
    const w = window.omelette && window.omelette.writeFile;
    if (!w) return;
    try {
      Promise.resolve(w(STATE_FILE, JSON.stringify(slots))).catch(() => {});
    } catch (e) {}
  }
  function save() {
    if (saving) {
      saveDirty = true;
      return;
    }
    const w = window.omelette && window.omelette.writeFile;
    if (!w) return;
    saving = true;
    Promise.resolve(w(STATE_FILE, JSON.stringify(slots))).catch(() => {}).then(() => {
      saving = false;
      if (saveDirty) {
        saveDirty = false;
        save();
      }
    });
  }
  const S_MAX = 5;
  const clampS = s => Math.max(1, Math.min(S_MAX, s));

  // Normalize a stored slot value. Pre-reframe sidecars stored a bare
  // data-URL string; newer ones store {u, s, x, y}. Either shape is valid.
  function getSlot(id) {
    const v = slots[id];
    if (!v) return null;
    return typeof v === 'string' ? {
      u: v,
      s: 1,
      x: 0,
      y: 0
    } : v;
  }
  function setSlot(id, val) {
    if (!id) return;
    if (val) {
      slots[id] = val;
      tombstones.delete(id);
    } else {
      delete slots[id];
      if (!loaded) tombstones.add(id);
    }
    subs.forEach(fn => fn());
    // A drop is rare + high-value — write immediately so nav-away can't lose
    // it. Gate on the initial read so we don't overwrite a sidecar we haven't
    // merged yet; the merge in load() keeps this change once the read lands.
    if (loaded) save();else load().then(save);
  }

  // ── Image downscale ─────────────────────────────────────────────────────
  // Encode through a canvas so the sidecar carries resized bytes, not the
  // raw upload. Longest side is capped at 2× the slot's rendered width
  // (retina) and at MAX_DIM. WebP keeps alpha and is ~10× smaller than PNG
  // for photos, so there's no need for per-image format picking.
  async function toDataUrl(file, targetW) {
    const bitmap = await createImageBitmap(file);
    try {
      const cap = Math.min(MAX_DIM, Math.max(1, Math.round(targetW * 2)) || MAX_DIM);
      const scale = Math.min(1, cap / Math.max(bitmap.width, bitmap.height));
      const w = Math.max(1, Math.round(bitmap.width * scale));
      const h = Math.max(1, Math.round(bitmap.height * scale));
      const canvas = document.createElement('canvas');
      canvas.width = w;
      canvas.height = h;
      canvas.getContext('2d').drawImage(bitmap, 0, 0, w, h);
      return canvas.toDataURL('image/webp', 0.85);
    } finally {
      bitmap.close && bitmap.close();
    }
  }

  // ── Custom element ──────────────────────────────────────────────────────
  const stylesheet =
  // Fill the container by default: slots are usually placed inside a
  // sized wrapper (a hero frame, a grid cell, an inset:0 layer) and are
  // expected to take that box — a fixed intrinsic size would render as
  // a small tile in the corner of a full-bleed wrapper instead.
  // aspect-ratio is the companion fallback that keeps a bare slot
  // visible when the parent's height is indefinite: height:100%
  // resolves to auto there, and the ratio then derives height from
  // width instead of letting the slot collapse to zero height.
  // Explicit width/height on the element override all of this.
  ':host{display:block;position:relative;' + '  font:13px/1.3 system-ui,-apple-system,sans-serif;color:rgba(0,0,0,.55);' + '  width:100%;height:100%;aspect-ratio:3/2}' + '.frame{position:absolute;inset:0;overflow:hidden;background:rgba(0,0,0,.04)}' +
  // .frame img (clipped) and .spill (unclipped ghost + handles) share the
  // same left/top/width/height in frame-%, computed by _applyView(), so the
  // inside-mask crop and the outside-mask spill stay pixel-aligned.
  '.frame img{position:absolute;max-width:none;transform:translate(-50%,-50%);' + '  -webkit-user-drag:none;user-select:none;touch-action:none}' +
  // Reframe mode (double-click): the full image spills past the mask. The
  // spill layer is sized to the IMAGE bounds so its corners are where the
  // resize handles belong. The ghost <img> inside is translucent; the real
  // clipped <img> underneath shows the opaque in-mask crop.
  // popover=manual promotes the spill to the top layer on reframe, so it is
  // not clipped by any overflow:hidden / clip-path / scroll-container
  // ancestor (a plain z-index can't escape overflow clipping). UA popover
  // defaults (inset:0;margin:auto) are reset; _applyView sets viewport px.
  '.spill{position:fixed;margin:0;inset:auto;border:0;padding:0;background:transparent;' + '  overflow:visible;transform:translate(-50%,-50%);z-index:1;cursor:grab;touch-action:none}' + ':host([data-panning]) .spill{cursor:grabbing}' + '.spill .ghost{position:absolute;inset:0;width:100%;height:100%;opacity:.35;' + '  pointer-events:none;-webkit-user-drag:none;user-select:none;' + '  box-shadow:0 0 0 1px rgba(0,0,0,.2),0 12px 32px rgba(0,0,0,.2)}' + '.spill .handle{position:absolute;width:12px;height:12px;border-radius:50%;' + '  background:#fff;box-shadow:0 0 0 1.5px #c96442,0 1px 3px rgba(0,0,0,.3);' + '  transform:translate(-50%,-50%)}' + '.spill .handle[data-c=nw]{left:0;top:0;cursor:nwse-resize}' + '.spill .handle[data-c=ne]{left:100%;top:0;cursor:nesw-resize}' + '.spill .handle[data-c=sw]{left:0;top:100%;cursor:nesw-resize}' + '.spill .handle[data-c=se]{left:100%;top:100%;cursor:nwse-resize}' + ':host([data-reframe]){z-index:10}' + ':host([data-reframe]) .frame{box-shadow:0 0 0 2px #c96442}' + '.empty{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;' + '  justify-content:center;gap:6px;text-align:center;padding:12px;box-sizing:border-box;' + '  cursor:pointer;user-select:none}' + '.empty svg{opacity:.45}' + '.empty .cap{max-width:90%;font-weight:500;letter-spacing:.01em}' + '.empty .sub{font-size:11px}' + '.empty .sub u{text-underline-offset:2px;text-decoration-color:rgba(0,0,0,.25)}' + '.empty:hover .sub u{color:rgba(0,0,0,.75);text-decoration-color:currentColor}' + ':host([data-over]) .frame{outline:2px solid #c96442;outline-offset:-2px;' + '  background:rgba(201,100,66,.10)}' + '.ring{position:absolute;inset:0;pointer-events:none;border:1.5px dashed rgba(0,0,0,.25);' + '  transition:border-color .12s}' + ':host([data-over]) .ring{border-color:#c96442}' + ':host([data-filled]) .ring{display:none}' +
  // Controls overlay INSIDE the frame, pinned to the top-right corner, so
  // a full-bleed slot in an overflow:hidden container still shows them
  // (the old below-mask placement got clipped). Credit sits bottom-left,
  // so top-right avoids collision. The blurred pill background keeps them
  // legible over the image.
  // The UA [popover] base rule styles the element in EVERY state (only
  // display:none is gated on :not(:popover-open), and the display:flex
  // below overrides that) — so the UA resets live HERE, like .spill's,
  // or the ordinary hover-state strip renders as a bordered Canvas box
  // centered by margin:auto. inset:auto precedes top/right (shorthand).
  '.ctl{position:absolute;inset:auto;top:8px;right:8px;margin:0;border:0;padding:0;' + '  background:transparent;overflow:visible;' + '  display:flex;gap:6px;opacity:0;pointer-events:none;transition:opacity .12s;z-index:2;' + '  white-space:nowrap}' +
  // While reframing, the spill owns the top layer and would swallow every
  // click on the in-frame controls. Promoting .ctl into the top layer
  // ABOVE the spill (shown after it — later popovers stack higher) keeps
  // Edit-as-toggle and Replace clickable mid-reframe. _applyView pins it
  // to the frame's top-right in viewport px (translateX(-100%)
  // right-aligns against the computed left edge); inset:auto clears the
  // base rule's top/right so the inline left/top position it alone.
  '.ctl:popover-open{position:fixed;inset:auto;transform:translateX(-100%)}' + ':host([data-filled][data-editable]:hover) .ctl,:host([data-reframe]) .ctl' + '  {opacity:1;pointer-events:auto}' + '.ctl button{appearance:none;border:0;border-radius:6px;padding:5px 10px;cursor:pointer;' + '  background:rgba(0,0,0,.65);color:#fff;font:11px/1 system-ui,-apple-system,sans-serif;' + '  backdrop-filter:blur(6px)}' + '.ctl button:hover{background:rgba(0,0,0,.8)}' + '.err{position:absolute;left:8px;bottom:8px;right:8px;color:#b3261e;font-size:11px;' + '  background:rgba(255,255,255,.85);padding:4px 6px;border-radius:5px;pointer-events:none}' +
  // Replacement in flight: after a src swap the browser keeps painting
  // the PREVIOUS image until the new one decodes, so a Replace would
  // flash the old photo and then pop. Hide the stale frame (visibility,
  // not display — _applyView geometry still applies) and spin until the
  // new image reports in (load/error clears data-swapping).
  ':host([data-swapping]) .frame img{visibility:hidden}' + '.loading{position:absolute;inset:0;display:none;align-items:center;' + '  justify-content:center;pointer-events:none}' + ':host([data-swapping]) .loading{display:flex}' + '.loading::after{content:"";width:22px;height:22px;border-radius:50%;' + '  border:2px solid rgba(0,0,0,.12);border-top-color:rgba(0,0,0,.45);' + '  animation:om-slot-spin .7s linear infinite}' + '@keyframes om-slot-spin{to{transform:rotate(360deg)}}' +
  // Reduced motion: the static two-tone ring still reads as "working".
  '@media (prefers-reduced-motion:reduce){.loading::after{animation:none}}' + '.credit{position:absolute;left:6px;bottom:6px;max-width:calc(100% - 12px);display:none;' + '  padding:3px 7px;border-radius:5px;background:rgba(0,0,0,.55);color:#fff;' + '  font:10px/1.2 system-ui,-apple-system,sans-serif;text-decoration:none;' + '  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;backdrop-filter:blur(6px)}' +
  // The credit is a SPAN holding one or two <a>s (Unsplash's prescribed
  // form links the photographer AND Unsplash) — anchors style inline so
  // the overlay reads as one line of text.
  '.credit a{color:inherit;text-decoration:none}' + '.credit a:hover,.credit a:focus-visible{text-decoration:underline}' + ':host([data-filled][data-credit]) .credit{display:block}' +
  // Exports must ship JUST the image — no hover controls, no credit chip
  // (the host marks <html data-om-exporting> for the capture window; the
  // page-level hide script can't reach shadow DOM, this rule can).
  ':host-context([data-om-exporting]) .ctl,' + ':host-context([data-om-exporting]) .credit{display:none !important}' +
  // No export-window mask rules here on purpose: the export capture
  // releases the replacement mask by REMOVING data-swapping (the
  // shadow-root pass in pages/export/shared.ts HIDE_EXPORT_CHROME_SCRIPT)
  // — attribute removal works in every engine (:host-context is
  // Chromium-only), is scoped by construction to slots actually
  // mid-swap, and hides the spinner through the same gate. A masked img
  // would otherwise be silently dropped from PPTX decks (the capture
  // walk skips visibility:hidden imgs).
  // Attribution error tile: REPLACES the photo when an Unsplash src has
  // no credit attribute — rendering the photo uncredited is the terms
  // violation, so the photo must not appear at all.
  // Calm and neutral on purpose (review feedback): the tile informs the
  // user; the fix instructions are machine-facing (usage docblock, tool
  // description, and the turn-end scan's bounce copy name the attributes
  // for the agent).
  '.attr-error{position:absolute;inset:0;display:none;flex-direction:column;align-items:center;' + '  justify-content:center;gap:6px;text-align:center;padding:12px;box-sizing:border-box;' + '  background:#f2f1ef;color:#6e6c66;user-select:none;' + '  font:13px/1.45 system-ui,-apple-system,sans-serif}' + '.attr-error svg{opacity:.55}' + '.attr-error .cap{max-width:92%;font-weight:500;letter-spacing:.01em}' + ':host([data-attribution-error]) .attr-error{display:flex}' + ':host([data-attribution-error]) .ring{display:none}';
  const icon = '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' + 'stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">' + '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/>' + '<path d="m21 15-5-5L5 21"/></svg>';
  const warnIcon = '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' + 'stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">' + '<path d="m21.73 18-8-14a2 2 0 0 0-3.46 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/>' + '<path d="M12 9v4"/><path d="M12 17h.01"/></svg>';
  class ImageSlot extends HTMLElement {
    static get observedAttributes() {
      return ['shape', 'radius', 'mask', 'fit', 'placeholder', 'src', 'id', 'credit', 'credit-href'];
    }

    /** Duplicate-slide hook (called by deck-stage, see its
     *  _remintDuplicateIds): copy this id's stored image, if any, under a
     *  freshly minted key and return that key — so a duplicated slide's
     *  slot keeps its dropped photo instead of reverting to the
     *  placeholder. 'isFree' is the caller's uniqueness check (document
     *  ids); candidates must ALSO be unused in the sidecar, which can
     *  hold keys from other pages sharing the project root. (An EMPTY
     *  slot on another page leaves no sidecar entry, so its id is not
     *  detectable here — a minted key can collide with it and that slot
     *  would show this photo. Same blast radius as two pages reusing an
     *  id by hand, which the shared sidecar already permits.) Returns null
     *  when no id could be minted (caller strips the id, today's
     *  behavior). */
    static cloneSlot(fromId, isFree) {
      if (typeof fromId !== 'string' || !fromId) return null;
      // Pre-hydration the store can't veto candidates or source the copy
      // — degrade to the strip (today's behavior) rather than mint
      // against keys we can't see yet. Any rendered (= droppable) slot
      // means load() has already settled.
      if (!loaded) return null;
      const stem = fromId.replace(/-\d+$/, '') || fromId;
      for (let n = 2; n < 100; n++) {
        const toId = stem + '-' + n;
        if (toId === fromId) continue;
        if (slots[toId] !== undefined) {
          // Reuse a key holding this exact value (bytes AND crop) if no
          // live element here owns it — a duplicate op the host refused
          // after minting leaves such a key behind, and reusing keeps
          // refused retries from accumulating one orphaned copy per
          // attempt. Full equality (not just bytes) so a byte-identical
          // key another PAGE owns with its own crop is stepped past, not
          // adopted or rewritten. (Entries without .u never match.)
          const prev = getSlot(toId);
          const cur = getSlot(fromId);
          if (!(prev && cur && prev.u && prev.u === cur.u && prev.s === cur.s && prev.x === cur.x && prev.y === cur.y && (typeof isFree !== 'function' || isFree(toId)))) continue;
          return toId;
        }
        if (typeof isFree === 'function' && !isFree(toId)) continue;
        const v = getSlot(fromId);
        if (v) setSlot(toId, Object.assign({}, v));
        return toId;
      }
      return null;
    }
    constructor() {
      super();
      // clonable: rail thumbnails deep-clone slides and carry this shadow
      // along; reuse an already-cloned root so upgrade-after-clone works.
      // (Deliberately NOT serializable — a getHTML consumer would embed
      // multi-MB sidecar data-URLs into serialized page HTML.)
      const root = this.shadowRoot || this.attachShadow({
        mode: 'open',
        clonable: true
      });
      // .spill and .ctl sit OUTSIDE .frame so overflow:hidden + border-radius
      // on the frame (circle, pill, rounded) can't clip them.
      root.innerHTML = '<style>' + stylesheet + '</style>' + '<div class="frame" part="frame">' + '  <img part="image" alt="" draggable="false" style="display:none">' + '  <div class="empty" part="empty">' + icon + '    <div class="cap"></div>' + '    <div class="sub">or <u>browse files</u></div></div>' + '  <div class="attr-error" part="attribution-error">' + warnIcon + '    <div class="cap">This photo needs attribution</div></div>' + '  <div class="loading" part="loading"></div>' + '  <div class="ring" part="ring"></div>' + '</div>' +
      // Outside .frame, like .spill/.ctl — the frame's overflow:hidden +
      // border-radius/clip-path would cut the credit off on circle/pill/mask.
      // A SPAN, not an <a>: the prescribed Unsplash credit holds two links
      // (photographer + Unsplash), built per-render in _render().
      '<span class="credit" part="credit"></span>' + '<div class="spill" popover="manual" data-dc-edit-transparent>' + '  <img class="ghost" alt="" draggable="false">' + '  <div class="handle" data-c="nw"></div><div class="handle" data-c="ne"></div>' + '  <div class="handle" data-c="sw"></div><div class="handle" data-c="se"></div>' + '</div>' +
      // data-dc-edit-transparent: the DC editor's edit-mode picker lets
      // clicks through for chrome marked with it (EDIT_TRANSPARENT_SEL)
      // — without it, Replace/Edit clicks in Edit mode are swallowed by
      // element selection and the controls look dead.
      '<div class="ctl" popover="manual" data-dc-edit-transparent><button data-act="replace" title="Replace image">Replace</button>' + '  <button data-act="edit" title="Reframe image">Edit</button></div>' + '<input type="file" accept="' + ACCEPT.join(',') + '" hidden>';
      this._frame = root.querySelector('.frame');
      this._ring = root.querySelector('.ring');
      this._img = root.querySelector('.frame img');
      this._empty = root.querySelector('.empty');
      this._cap = root.querySelector('.cap');
      this._sub = root.querySelector('.sub');
      this._spill = root.querySelector('.spill');
      this._ctl = root.querySelector('.ctl');
      this._credit = root.querySelector('.credit');
      this._attrError = root.querySelector('.attr-error');
      // Credit clicks open the link, not browse/reframe.
      this._credit.addEventListener('click', e => e.stopPropagation());
      this._credit.addEventListener('dblclick', e => e.stopPropagation());
      this._ghost = root.querySelector('.ghost');
      this._err = null;
      this._input = root.querySelector('input');
      this._depth = 0;
      this._gen = 0;
      // Encode-in-flight marker (the owning _ingest generation): while set,
      // the same-src "nothing in flight" clear in _render must not fire —
      // the stored value still points at the OLD image until the encode
      // lands, so that clear would unmask the stale image mid-replace.
      this._swapGen = 0;
      // Render-owned swap in flight: set when _render assigns a new src,
      // cleared only by the img's own load/error (or the empty branch).
      // img.complete CANNOT stand in for this — setting src only QUEUES
      // the current-request swap (a microtask), so synchronously after an
      // assignment, complete still reports the OLD settled request. The
      // pick path does exactly that: the host sets src, credit, and
      // credit-href back-to-back in one task, and renders #2/#3 would
      // read the stale complete === true and drop the mask one render
      // after it was set.
      this._loadPending = false;
      // See _render's empty branch: a transient attribution-error wipe of a
      // showing image must make the follow-up render a replacement (spinner),
      // not a first fill (blank frame).
      this._hidShowing = false;
      this._view = {
        s: 1,
        x: 0,
        y: 0
      };
      this._subFn = () => this._render();
      // Shadow-DOM listeners live with the shadow DOM — bound once here so
      // disconnect/reconnect (e.g. React remount) doesn't stack handlers.
      this._empty.addEventListener('click', () => this._input.click());
      root.addEventListener('click', e => {
        const act = e.target && e.target.getAttribute && e.target.getAttribute('data-act');
        if (!act) return;
        // The hidden controls are opacity-0 but still tabbable — without
        // this gate a keyboard user could drive them on a read-only share
        // link (mirrors the dblclick handler's editable gate).
        if (!this.hasAttribute('data-editable')) return;
        if (act === 'replace') {
          this._exitReframe(true);
          // Host-owned picker (Unsplash modal; it also offers local import).
          this.dispatchEvent(new CustomEvent('image-slot:pick', {
            bubbles: true,
            composed: true,
            detail: {
              id: this.id || null
            }
          }));
        }
        if (act === 'edit') {
          if (!this._reframes()) return;
          if (this.hasAttribute('data-reframe')) this._exitReframe(true);else this._enterReframe();
        }
      });
      this._input.addEventListener('change', () => {
        const f = this._input.files && this._input.files[0];
        if (f) this._ingest(f);
        this._input.value = '';
      });
      // naturalWidth/Height aren't known until load — re-apply so the cover
      // baseline is computed from real dimensions, not the 100%×100% fallback.
      // load/error also release the replacement-in-flight mask (via the
      // single discipline in _releaseMask): the swap is only revealed once
      // the new image can actually paint (on error the frame shows its
      // background, same as a fresh slot with a broken src).
      this._img.addEventListener('load', () => {
        this._loadPending = false;
        this._releaseMask(true);
        this._applyView();
      });
      this._img.addEventListener('error', () => {
        this._loadPending = false;
        this._releaseMask(true);
      });
      // Gated only on editable — any filled slot can be repositioned/scaled,
      // regardless of fit. Share links (no writeFile) stay static.
      this.addEventListener('dblclick', e => {
        if (!this.hasAttribute('data-editable') || !this._reframes()) return;
        e.preventDefault();
        if (this.hasAttribute('data-reframe')) this._exitReframe(true);else this._enterReframe();
      });
      // Pan + resize both originate on the spill layer. A handle pointerdown
      // drives an aspect-locked resize anchored at the opposite corner; any
      // other pointerdown on the spill pans. Offsets are frame-% so a
      // reframed slot survives responsive resize / PPTX export.
      this._spill.addEventListener('pointerdown', e => {
        if (e.button !== 0 || !this.hasAttribute('data-reframe')) return;
        e.preventDefault();
        e.stopPropagation();
        this._spill.setPointerCapture(e.pointerId);
        const rect = this.getBoundingClientRect();
        const fw = rect.width || 1,
          fh = rect.height || 1;
        const corner = e.target.getAttribute && e.target.getAttribute('data-c');
        let move;
        if (corner) {
          // Resize about the OPPOSITE corner. Viewport-px throughout (rect
          // fw/fh, not clientWidth) so the math survives a transform:scale()
          // ancestor — deck_stage renders slides scaled-to-fit.
          const iw = this._img.naturalWidth || 1,
            ih = this._img.naturalHeight || 1;
          const contain = (this.getAttribute('fit') || 'cover').toLowerCase() === 'contain';
          const base = contain ? Math.min(fw / iw, fh / ih) : Math.max(fw / iw, fh / ih);
          const sx = corner.includes('e') ? 1 : -1;
          const sy = corner.includes('s') ? 1 : -1;
          const s0 = this._view.s;
          const w0 = iw * base * s0,
            h0 = ih * base * s0;
          const cx0 = (50 + this._view.x) / 100 * fw;
          const cy0 = (50 + this._view.y) / 100 * fh;
          const ox = cx0 - sx * w0 / 2,
            oy = cy0 - sy * h0 / 2;
          const diag0 = Math.hypot(w0, h0);
          const ux = sx * w0 / diag0,
            uy = sy * h0 / diag0;
          move = ev => {
            const proj = (ev.clientX - rect.left - ox) * ux + (ev.clientY - rect.top - oy) * uy;
            const s = clampS(s0 * proj / diag0);
            const d = diag0 * s / s0;
            this._view.s = s;
            this._view.x = (ox + ux * d / 2) / fw * 100 - 50;
            this._view.y = (oy + uy * d / 2) / fh * 100 - 50;
            this._clampView();
            this._applyView();
          };
        } else {
          this.setAttribute('data-panning', '');
          const start = {
            px: e.clientX,
            py: e.clientY,
            x: this._view.x,
            y: this._view.y
          };
          move = ev => {
            this._view.x = start.x + (ev.clientX - start.px) / fw * 100;
            this._view.y = start.y + (ev.clientY - start.py) / fh * 100;
            this._clampView();
            this._applyView();
          };
        }
        const up = () => {
          try {
            this._spill.releasePointerCapture(e.pointerId);
          } catch {}
          this._spill.removeEventListener('pointermove', move);
          this._spill.removeEventListener('pointerup', up);
          this._spill.removeEventListener('pointercancel', up);
          this.removeAttribute('data-panning');
          this._dragUp = null;
        };
        // Stashed so _exitReframe (Escape / outside-click mid-drag) can
        // tear the capture + listeners down synchronously.
        this._dragUp = up;
        this._spill.addEventListener('pointermove', move);
        this._spill.addEventListener('pointerup', up);
        this._spill.addEventListener('pointercancel', up);
      });
      // Wheel zoom stays available inside reframe mode as a trackpad nicety —
      // zooms toward the cursor (offset' = cursor·(1-k) + offset·k).
      this.addEventListener('wheel', e => {
        if (!this.hasAttribute('data-reframe')) return;
        e.preventDefault();
        const r = this.getBoundingClientRect();
        const cx = (e.clientX - r.left) / r.width * 100 - 50;
        const cy = (e.clientY - r.top) / r.height * 100 - 50;
        const prev = this._view.s;
        const next = clampS(prev * Math.pow(1.0015, -e.deltaY));
        if (next === prev) return;
        const k = next / prev;
        this._view.s = next;
        this._view.x = cx * (1 - k) + this._view.x * k;
        this._view.y = cy * (1 - k) + this._view.y * k;
        this._clampView();
        this._applyView();
      }, {
        passive: false
      });
    }
    connectedCallback() {
      // Warn once per page — an id-less slot works for the session but
      // cannot persist, and two id-less slots would share nothing.
      if (!this.id && !ImageSlot._warned) {
        ImageSlot._warned = true;
        console.warn('<image-slot> without an id will not persist its dropped image.');
      }
      this.addEventListener('dragenter', this);
      this.addEventListener('dragover', this);
      this.addEventListener('dragleave', this);
      this.addEventListener('drop', this);
      subs.add(this._subFn);
      // The host may inject window.omelette.writeFile AFTER the first render;
      // re-render on hover so the editable-gated controls reliably appear.
      this.addEventListener('pointerenter', this._subFn);
      // width%/height% in _applyView encode the frame aspect at call time —
      // a host resize (responsive grid, pane divider) would stretch the
      // image until the next _render. Re-render on size change: _render()
      // re-seeds _view from stored before clamp/apply, so a shrink→grow
      // cycle round-trips instead of ratcheting x/y toward the narrower
      // frame's clamp range.
      this._ro = new ResizeObserver(() => this._render());
      this._ro.observe(this);
      load();
      this._render();
    }
    disconnectedCallback() {
      subs.delete(this._subFn);
      this.removeEventListener('pointerenter', this._subFn);
      this.removeEventListener('dragenter', this);
      this.removeEventListener('dragover', this);
      this.removeEventListener('dragleave', this);
      this.removeEventListener('drop', this);
      if (this._ro) {
        this._ro.disconnect();
        this._ro = null;
      }
      // commit=false: a disconnect is not a user intent — committing here
      // would persist whatever half-finished drag a React remount or DOM
      // splice happened to interrupt. Deliberate exits commit on their own
      // paths (Escape/click-out/toggle), and unloads commit via pagehide.
      this._exitReframe(false);
    }
    _enterReframe() {
      if (this.hasAttribute('data-reframe')) return;
      this.setAttribute('data-reframe', '');
      this._signalReframe(true);
      // Best-effort commit when the document unloads mid-reframe (a host
      // navigation racing the enter signal, a manual reload, tab close):
      // the sidecar write rides the host bridge, which outlives this
      // document, so the crop survives even though the mode dies with the
      // DOM. Held on the instance so _exitReframe detaches exactly what
      // was attached.
      this._pagehide = () => {
        this._exitReframe(true);
        flushNow();
      };
      window.addEventListener('pagehide', this._pagehide);
      // Promote spill to the top layer, then keep it pinned over the frame:
      // scroll/resize cover the common cases, and a per-frame rect check
      // catches layout shifts that fire neither (an image above finishing
      // load, streamed DOM pushing the slot down, an ancestor transform
      // change) so the overlay can't detach from the frame.
      try {
        this._spill.showPopover();
      } catch {}
      // After the spill, so the controls stack above it in the top layer.
      try {
        this._ctl.showPopover();
      } catch {}
      this._reposition = () => {
        if (this.hasAttribute('data-reframe')) this._applyView();
      };
      window.addEventListener('scroll', this._reposition, true);
      window.addEventListener('resize', this._reposition);
      this._lastRect = '';
      this._watch = () => {
        if (!this.hasAttribute('data-reframe')) return;
        const r = this.getBoundingClientRect();
        const key = r.left + ',' + r.top + ',' + r.width + ',' + r.height;
        if (key !== this._lastRect) {
          this._lastRect = key;
          this._applyView();
        }
        this._watchId = requestAnimationFrame(this._watch);
      };
      this._watchId = requestAnimationFrame(this._watch);
      this._applyView();
      // Close on click outside (the spill handler stopPropagation()s so
      // in-image drags don't reach this) and on Escape. Listeners are held
      // on the instance so _exitReframe / disconnectedCallback can detach
      // exactly what was attached.
      this._outside = e => {
        if (e.composedPath && e.composedPath().includes(this)) return;
        this._exitReframe(true);
      };
      this._esc = e => {
        if (e.key === 'Escape') this._exitReframe(true);
      };
      document.addEventListener('pointerdown', this._outside, true);
      document.addEventListener('keydown', this._esc, true);
    }
    _exitReframe(commit) {
      if (!this.hasAttribute('data-reframe')) return;
      if (this._dragUp) this._dragUp();
      this.removeAttribute('data-reframe');
      this.removeAttribute('data-panning');
      if (this._outside) document.removeEventListener('pointerdown', this._outside, true);
      if (this._esc) document.removeEventListener('keydown', this._esc, true);
      this._outside = this._esc = null;
      if (this._reposition) {
        window.removeEventListener('scroll', this._reposition, true);
        window.removeEventListener('resize', this._reposition);
        this._reposition = null;
      }
      if (this._watchId) {
        cancelAnimationFrame(this._watchId);
        this._watchId = 0;
      }
      if (this._pagehide) {
        window.removeEventListener('pagehide', this._pagehide);
        this._pagehide = null;
      }
      try {
        this._spill.hidePopover();
      } catch {}
      try {
        this._ctl.hidePopover();
      } catch {}
      this._ctl.style.left = '';
      this._ctl.style.top = '';
      if (commit) this._commitView();
      this._signalReframe(false);
    }

    // Reframe state lives only in this DOM until commit, invisible to the
    // host's dirty signals — announce enter/exit so the host can hold
    // auto-reloads for exactly the gesture (the guest bundle forwards
    // image-slot:reframe to the host as imageSlotReframe). Dispatched on
    // the element (composed, so it escapes shadow roots) while connected;
    // a disconnected exit (disconnectedCallback) falls back to document so
    // the host still hears it.
    _signalReframe(active) {
      const target = this.isConnected ? this : document;
      target.dispatchEvent(new CustomEvent('image-slot:reframe', {
        bubbles: true,
        composed: true,
        detail: {
          active: active,
          id: this.id || null
        }
      }));
    }

    // Public: host's "Import from computer" calls this to run local browse.
    openFilePicker() {
      this._exitReframe(true);
      this._input.click();
    }
    attributeChangedCallback() {
      if (this.shadowRoot) this._render();
    }

    // handleEvent — one listener object for all four drag events keeps the
    // add/remove symmetric and the depth counter correct.
    handleEvent(e) {
      if (e.type === 'dragenter' || e.type === 'dragover') {
        // Without preventDefault the browser never fires 'drop'.
        e.preventDefault();
        e.stopPropagation();
        if (e.dataTransfer) e.dataTransfer.dropEffect = 'copy';
        if (e.type === 'dragenter') this._depth++;
        this.setAttribute('data-over', '');
      } else if (e.type === 'dragleave') {
        // dragenter/leave fire for every descendant crossing — count depth
        // so hovering the icon inside the empty state doesn't flicker.
        if (--this._depth <= 0) {
          this._depth = 0;
          this.removeAttribute('data-over');
        }
      } else if (e.type === 'drop') {
        e.preventDefault();
        e.stopPropagation();
        this._depth = 0;
        this.removeAttribute('data-over');
        const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
        if (f) this._ingest(f);
      }
    }
    async _ingest(file) {
      this._setError(null);
      if (!file || ACCEPT.indexOf(file.type) < 0) {
        this._setError('Drop a PNG, JPEG, WebP, or AVIF image.');
        return;
      }
      // toDataUrl can take hundreds of ms on a large photo. A Clear or a
      // newer drop during that window would be clobbered when this await
      // resumes — bump + capture a generation so stale encodes bail.
      const gen = ++this._gen;
      // Replacing a shown image: surface the swap through the encode too,
      // not just the decode — otherwise the old photo sits there with no
      // feedback while the canvas re-encode runs. An empty slot keeps its
      // placeholder (no spinner) until the encode lands, as before.
      // _swapGen guards the mask against re-renders DURING the encode
      // (pointerenter, ResizeObserver, another slot's store write): the
      // stored value still resolves to the old image there, so _render's
      // same-src clear would otherwise unmask it mid-replace.
      if (this.hasAttribute('data-filled')) {
        this.setAttribute('data-swapping', '');
        this._swapGen = gen;
      }
      try {
        const w = this.clientWidth || this.offsetWidth || MAX_DIM;
        const url = await toDataUrl(file, w);
        if (gen !== this._gen) return;
        // Only exit reframe once the new image is in hand — a rejected type
        // or decode failure leaves the in-progress crop untouched.
        this._exitReframe(false);
        // Clear BEFORE setSlot: its synchronous re-render must see no
        // pending encode, so a byte-identical re-upload (same data URL, no
        // load event coming) still clears the mask via the complete branch.
        this._swapGen = 0;
        const val = {
          u: url,
          s: 1,
          x: 0,
          y: 0
        };
        setSlot(this.id || '', val);
        // Keep a session-local copy for id-less slots so the drop still
        // shows, even though it cannot persist.
        if (!this.id) {
          this._local = val;
          this._render();
        }
      } catch (err) {
        if (gen !== this._gen) return;
        this._swapGen = 0;
        // Reveal the kept old image — unless another replacement (a
        // remote pick's src swap) is still in flight, in which case the
        // mask stays until THAT image settles (its load/error releases).
        this._releaseMask();
        this._setError('Could not read that image.');
        console.warn('<image-slot> ingest failed:', err);
      }
    }
    _setError(msg) {
      if (this._err) {
        this._err.remove();
        this._err = null;
      }
      if (!msg) return;
      const d = document.createElement('div');
      d.className = 'err';
      d.textContent = msg;
      this.shadowRoot.appendChild(d);
      this._err = d;
      setTimeout(() => {
        if (this._err === d) {
          d.remove();
          this._err = null;
        }
      }, 3000);
    }

    // Reframing (pan/resize) is available on any filled slot — the user can
    // always reposition/scale. `fit` only sets the initial baseline (see
    // _geom): contain starts fully-visible, cover starts frame-filling.
    _reframes() {
      return this.hasAttribute('data-filled');
    }

    // The single release discipline for the replacement-in-flight mask
    // (data-swapping). The mask comes off only when BOTH hold:
    //  - no encode is pending (_swapGen) — mid-encode the stored value
    //    still resolves to the old image, so any reveal paints it;
    //  - the frame img has settled on its current src — an unsettled src
    //    means some replacement is still in flight (e.g. a remote pick),
    //    whoever started it, and revealing would paint the previous
    //    frame. The load/error listeners pass settled=true (the event IS
    //    the settlement signal, per spec complete is true by then);
    //    other callers rely on the complete flag (covers loaded AND
    //    failed).
    // Every release path funnels through here EXCEPT _render's empty
    // branch (the img is being cleared — nothing will ever settle).
    _releaseMask(settled) {
      if (!this._swapGen && !this._loadPending && (settled || this._img.complete)) {
        this.removeAttribute('data-swapping');
      }
    }

    // Baseline geometry, shared by clamp/apply/resize. `base` is the scale at
    // view-scale s=1: cover = fill the frame (overflow on the looser axis),
    // contain = fit fully inside (letterboxed). Zooming a contain image past
    // s where it overflows naturally becomes a crop. Null until the img has
    // loaded (naturalWidth is 0 before that) or when the slot has no layout
    // box — ResizeObserver fires with a 0×0 rect under display:none, and
    // clamping against a degenerate 1×1 frame would silently pull the stored
    // pan toward zero.
    _geom() {
      const iw = this._img.naturalWidth,
        ih = this._img.naturalHeight;
      const fw = this.clientWidth,
        fh = this.clientHeight;
      if (!iw || !ih || !fw || !fh) return null;
      const contain = (this.getAttribute('fit') || 'cover').toLowerCase() === 'contain';
      const base = contain ? Math.min(fw / iw, fh / ih) : Math.max(fw / iw, fh / ih);
      return {
        iw,
        ih,
        fw,
        fh,
        base
      };
    }
    _clampView() {
      // Pan range on each axis is half the overflow past the frame edge.
      const g = this._geom();
      if (!g) return;
      const mx = Math.max(0, (g.iw * g.base * this._view.s / g.fw - 1) * 50);
      const my = Math.max(0, (g.ih * g.base * this._view.s / g.fh - 1) * 50);
      this._view.x = Math.max(-mx, Math.min(mx, this._view.x));
      this._view.y = Math.max(-my, Math.min(my, this._view.y));
    }
    _applyView() {
      const g = this._geom();
      // Top-layer controls: pin to the frame's top-right in viewport px
      // (the same 8px inset as the in-frame layout; unscaled — top-layer UI
      // reads as chrome, not page content). BEFORE the geometry branch:
      // placement needs only the frame rect, and a not-yet-loaded or broken
      // src must not leave the promoted strip floating unpositioned. Gated
      // on the popover actually being open: without the Popover API,
      // showPopover() threw (swallowed in _enterReframe), .ctl stays in
      // its in-frame absolute layout, and viewport-px coordinates would
      // shove it off-frame — and matches(':popover-open') itself throws
      // there (unknown pseudo-class), hence the try/catch.
      if (this.hasAttribute('data-reframe')) {
        let onTop = false;
        try {
          onTop = this._ctl.matches(':popover-open');
        } catch {}
        if (onTop) {
          const r = this.getBoundingClientRect();
          this._ctl.style.left = r.right - 8 + 'px';
          this._ctl.style.top = r.top + 8 + 'px';
        }
      }
      if (!g) {
        // Dimensions not known yet (before img load) — centered fit so there
        // is no flash of an unpositioned image before the geometry lands.
        const contain = (this.getAttribute('fit') || 'cover').toLowerCase() === 'contain';
        this._img.style.width = '100%';
        this._img.style.height = '100%';
        this._img.style.left = '50%';
        this._img.style.top = '50%';
        this._img.style.objectFit = contain ? 'contain' : 'cover';
        return;
      }
      // Baseline (cover-fill or contain-fit) × view scale. Width/height and
      // left/top are all frame-% — depends only on the frame aspect ratio, so
      // a responsive resize keeps the same crop. The spill layer mirrors the
      // same box so its corners = image corners.
      const k = g.base * this._view.s;
      const w = g.iw * k / g.fw * 100 + '%';
      const h = g.ih * k / g.fh * 100 + '%';
      const l = 50 + this._view.x + '%';
      const t = 50 + this._view.y + '%';
      this._img.style.width = w;
      this._img.style.height = h;
      this._img.style.left = l;
      this._img.style.top = t;
      this._img.style.objectFit = '';
      if (this.hasAttribute('data-reframe')) {
        // Top-layer spill: position in viewport px over the frame. The top
        // layer escapes ancestor transforms entirely, so EVERY term must be
        // in viewport units: getBoundingClientRect gives the frame's scaled
        // origin AND size, and the rect/layout ratio rescales the ghost —
        // sizing from layout px alone renders it 1/scale too large under a
        // scaled deck slide. Inner ghost + handles stay box-relative.
        const r = this.getBoundingClientRect();
        const sx = g.fw ? r.width / g.fw : 1;
        const sy = g.fh ? r.height / g.fh : 1;
        this._spill.style.width = g.iw * k * sx + 'px';
        this._spill.style.height = g.ih * k * sy + 'px';
        this._spill.style.left = r.left + (50 + this._view.x) / 100 * r.width + 'px';
        this._spill.style.top = r.top + (50 + this._view.y) / 100 * r.height + 'px';
      }
    }
    _commitView() {
      const v = {
        s: this._view.s,
        x: this._view.x,
        y: this._view.y
      };
      if (this._userUrl) v.u = this._userUrl;
      // Framing-only (no u) persists too so an author-src slot remembers its
      // crop; clearing the sidecar still falls through to src=.
      if (this.id) setSlot(this.id, v);else {
        this._local = v;
      }
    }
    _render() {
      // Shape / mask. Presets use border-radius so the dashed ring can
      // follow the rounded outline; clip-path is only applied for an
      // explicit `mask` (the ring is hidden there since a rectangle
      // dashed border chopped by an arbitrary polygon looks broken).
      const mask = this.getAttribute('mask');
      const shape = (this.getAttribute('shape') || 'rounded').toLowerCase();
      let radius = '';
      if (shape === 'circle') radius = '50%';else if (shape === 'pill') radius = '9999px';else if (shape === 'rounded') {
        const n = parseFloat(this.getAttribute('radius'));
        radius = (Number.isFinite(n) ? n : 12) + 'px';
      }
      this._frame.style.borderRadius = mask ? '' : radius;
      this._frame.style.clipPath = mask || '';
      this._ring.style.borderRadius = mask ? '' : radius;
      this._ring.style.display = mask ? 'none' : '';

      // Controls and reframe entry gate on this so share links stay read-only.
      const editable = !!(window.omelette && window.omelette.writeFile);
      this.toggleAttribute('data-editable', editable);
      this._sub.style.display = editable ? '' : 'none';

      // Content. The sidecar is also writable by the agent's write_file
      // tool, so its value isn't guaranteed canvas-originated — only accept
      // data:image/ URLs from it. The `src` attribute is author-controlled
      // (Claude wrote it into the HTML) so it passes through unchanged.
      let stored = this.id ? getSlot(this.id) : this._local;
      if (stored && stored.u && !/^data:image\//i.test(stored.u)) stored = null;
      const srcAttr = this.getAttribute('src') || '';
      this._userUrl = stored && stored.u || null;
      const url = this._userUrl || srcAttr;
      // Don't clobber an in-flight reframe with a store-triggered re-render.
      if (!this.hasAttribute('data-reframe')) {
        this._view = {
          s: stored && Number.isFinite(stored.s) ? clampS(stored.s) : 1,
          x: stored && Number.isFinite(stored.x) ? stored.x : 0,
          y: stored && Number.isFinite(stored.y) ? stored.y : 0
        };
      }
      this._cap.textContent = this.getAttribute('placeholder') || 'Drop an image';
      // Toggle via style.display — the [hidden] attribute alone loses to
      // the display:flex / display:block rules in the stylesheet above.
      // An Unsplash src with no credit attribute must NOT render — showing
      // the photo uncredited is the Unsplash-terms violation itself. The
      // error tile replaces the photo until the credit is written. A
      // user-dropped image is the user's own content and always renders.
      // Trimmed: credit is agent/user-editable content, and a whitespace-
      // only value must count as missing — otherwise it would suppress the
      // error tile AND render an empty credit box (no text, no links),
      // exactly the unattributed state this gate exists to prevent.
      const credit = (this.getAttribute('credit') || '').trim();
      const attrError = !!(!credit && !this._userUrl && srcAttr && isUnsplashHost(srcAttr));
      this.toggleAttribute('data-attribution-error', attrError);
      if (url && !attrError) {
        const prev = this._img.getAttribute('src');
        if (prev !== url) {
          // Replacing an already-shown image: mark the swap BEFORE setting
          // src so the stale frame is never revealed (see the data-swapping
          // stylesheet rules). First fill (prev empty) keeps the existing
          // placeholder-until-load behavior — no spinner. _hidShowing
          // covers the pick path's transient attribution-error wipe: prev
          // is gone, but an image WAS showing, so this is a replacement.
          if (prev || this._hidShowing) this.setAttribute('data-swapping', '');
          // Mark the swap BEFORE assigning src: complete keeps reporting
          // the old settled request until the browser's
          // update-the-image-data microtask runs, so same-task re-renders
          // (the pick path's credit/credit-href setAttributes) need this
          // flag, not complete, to know a load is in flight.
          this._loadPending = true;
          this._img.src = url;
          this._ghost.src = url;
        } else {
          // Same-src re-render — release if settled, so an ingest-set
          // spinner can't stick after a byte-identical re-upload (same
          // data URL, no further load event ever fires).
          this._releaseMask();
        }
        this._hidShowing = false;
        this._img.style.display = 'block';
        this._empty.style.display = 'none';
        this.setAttribute('data-filled', '');
        this._clampView();
        this._applyView();
      } else {
        this.removeAttribute('data-swapping');
        // The src is being removed — no load/error will ever fire for it.
        this._loadPending = false;
        // A transient attribution-error wipe of a showing image happens on
        // the pick path: the host sets src one setAttribute before credit,
        // so render N hides the old image (attrError) and render N+1
        // restores a URL. Remember the wipe so that restore renders as a
        // replacement (spinner), not a first fill (blank frame).
        this._hidShowing = attrError && !!this._img.getAttribute('src');
        this._img.style.display = 'none';
        this._img.removeAttribute('src');
        this._ghost.removeAttribute('src');
        // The error tile owns the blocked-photo state; .empty stays for
        // the genuinely-empty slot.
        this._empty.style.display = attrError ? 'none' : 'flex';
        this.removeAttribute('data-filled');
      }

      // Credit belongs to the author src, so a user drop hides it.
      // textContent + the http(s)-only funnel keep external strings inert.
      const showCredit = !!(url && credit && !this._userUrl && !attrError);
      this._credit.textContent = '';
      if (showCredit) {
        // Validate once (resolved against the document, http(s) only),
        // then append the terms-required utm referral params to links
        // that point back at unsplash.com.
        let href = '';
        const rawHref = this.getAttribute('credit-href') || '';
        if (rawHref) {
          try {
            const u = new URL(rawHref, document.baseURI);
            if (u.protocol === 'http:' || u.protocol === 'https:') {
              href = withReferral(u.href);
            }
          } catch {}
        }
        const mkLink = (text, linkHref) => {
          const a = document.createElement('a');
          a.setAttribute('target', '_blank');
          a.setAttribute('rel', 'noopener noreferrer');
          a.setAttribute('href', linkHref);
          a.textContent = text;
          return a;
        };
        // Unsplash's prescribed credit is TWO links — the photographer's
        // name to their profile (credit-href) and 'Unsplash' to the
        // homepage. Render that split whenever the text has the canonical
        // shape; other text keeps the legacy single-link rendering.
        const m = /^Photo by (.+) on Unsplash$/.exec(credit);
        if (m) {
          this._credit.appendChild(document.createTextNode('Photo by '));
          this._credit.appendChild(href ? mkLink(m[1], href) : document.createTextNode(m[1]));
          this._credit.appendChild(document.createTextNode(' on '));
          this._credit.appendChild(mkLink('Unsplash', UNSPLASH_HOMEPAGE_HREF));
        } else if (href) {
          this._credit.appendChild(mkLink(credit, href));
        } else {
          this._credit.textContent = credit;
        }
      }
      this.toggleAttribute('data-credit', showCredit);
    }
  }
  if (!customElements.get('image-slot')) {
    customElements.define('image-slot', ImageSlot);
  }
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/institutional/image-slot.js", error: String((e && e.message) || e) }); }

// ui_kits/institutional/instAbout.jsx
try { (() => {
/* You Contabilidade, Institutional: about + stats + process */
const {
  SectionHeading,
  Stat,
  Button
} = window.YouNewDS_5cb4d2;
const AbI = n => /*#__PURE__*/React.createElement("i", {
  "data-lucide": n
});
function About() {
  const points = ['Especialistas em marketplace e negócios digitais', 'Atendimento humano, seu contador no WhatsApp', 'Tecnologia + contador de verdade, sem robô', 'Sem fidelidade e sem letras miúdas'];
  return /*#__PURE__*/React.createElement("section", {
    className: "i-section",
    id: "sobre"
  }, /*#__PURE__*/React.createElement("div", {
    className: "i-container i-about"
  }, /*#__PURE__*/React.createElement("div", {
    className: "i-body"
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    align: "left",
    eyebrow: "Sobre a You",
    title: /*#__PURE__*/React.createElement(React.Fragment, null, "Descomplicamos a contabilidade de quem ", /*#__PURE__*/React.createElement("em", null, "vende online"))
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 22
    }
  }, /*#__PURE__*/React.createElement("p", null, "Nascemos para resolver um problema real: contador comum n\xE3o entende de marketplace. Repasse, tarifa, antecipa\xE7\xE3o, imposto sobre venda online, a gente domina isso."), /*#__PURE__*/React.createElement("p", null, "Hoje cuidamos do CNPJ de milhares de vendedores e empresas em todo o Brasil, unindo tecnologia a um time de contadores que atende de gente para gente."), /*#__PURE__*/React.createElement("ul", {
    className: "i-check-list"
  }, points.map(p => /*#__PURE__*/React.createElement("li", {
    key: p
  }, /*#__PURE__*/React.createElement("span", {
    className: "ic"
  }, AbI('check')), p))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 28
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    href: "#contato",
    rightIcon: AbI('arrow-right')
  }, "Fale com a gente")))), /*#__PURE__*/React.createElement("div", {
    className: "i-about__stats"
  }, /*#__PURE__*/React.createElement(Stat, {
    value: "+XXX",
    label: "clientes atendidos"
  }), /*#__PURE__*/React.createElement(Stat, {
    value: "XX anos",
    label: "de experi\xEAncia"
  }), /*#__PURE__*/React.createElement(Stat, {
    value: "R$ XXM",
    label: "em impostos economizados"
  }), /*#__PURE__*/React.createElement(Stat, {
    value: "X,X\u2605",
    label: "avalia\xE7\xE3o no Google"
  }))));
}
function Process() {
  const steps = [['search', 'Diagnóstico', 'Entendemos seu negócio, suas vendas e onde dá para economizar.'], ['rocket', 'Onboarding', 'Abrimos ou migramos seu CNPJ e configuramos tudo por você.'], ['repeat', 'Rotina mensal', 'Cuidamos de impostos, notas e prazos, você acompanha pelo app.'], ['trending-up', 'Crescimento', 'Consultoria contínua para escalar com segurança fiscal.']];
  return /*#__PURE__*/React.createElement("section", {
    className: "i-section i-alt",
    id: "processo"
  }, /*#__PURE__*/React.createElement("div", {
    className: "i-container"
  }, /*#__PURE__*/React.createElement("div", {
    className: "i-head-wrap"
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    align: "center",
    eyebrow: "Como trabalhamos",
    title: /*#__PURE__*/React.createElement(React.Fragment, null, "Do primeiro contato ao ", /*#__PURE__*/React.createElement("em", null, "crescimento"))
  })), /*#__PURE__*/React.createElement("div", {
    className: "i-proc"
  }, steps.map((s, i) => /*#__PURE__*/React.createElement("div", {
    className: "i-proc__step",
    key: i
  }, /*#__PURE__*/React.createElement("div", {
    className: "i-proc__n"
  }, i + 1), /*#__PURE__*/React.createElement("h4", null, s[1]), /*#__PURE__*/React.createElement("p", null, s[2]))))));
}
Object.assign(window, {
  About,
  Process
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/institutional/instAbout.jsx", error: String((e && e.message) || e) }); }

// ui_kits/institutional/instApp.jsx
try { (() => {
/* You Contabilidade, Institutional: page composition */
function InstitutionalApp() {
  const [menu, setMenu] = React.useState(false);
  React.useEffect(() => {
    if (window.lucide) window.lucide.createIcons();
  });
  return /*#__PURE__*/React.createElement("div", {
    className: "i-page"
  }, /*#__PURE__*/React.createElement(Header, {
    onMenu: () => setMenu(m => !m),
    menuOpen: menu
  }), menu && /*#__PURE__*/React.createElement(MobileMenu, {
    onClose: () => setMenu(false)
  }), /*#__PURE__*/React.createElement("main", null, /*#__PURE__*/React.createElement(Hero, null), /*#__PURE__*/React.createElement(Services, null), /*#__PURE__*/React.createElement(Segments, null), /*#__PURE__*/React.createElement(About, null), /*#__PURE__*/React.createElement(Process, null), /*#__PURE__*/React.createElement(Contact, null), /*#__PURE__*/React.createElement(CTABand, null)), /*#__PURE__*/React.createElement(Footer, null), /*#__PURE__*/React.createElement(WhatsAppFloat, null));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(InstitutionalApp, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/institutional/instApp.jsx", error: String((e && e.message) || e) }); }

// ui_kits/institutional/instContact.jsx
try { (() => {
/* You Contabilidade — Institucional: contato com formulário escuro (modelo diagnóstico) */
const {
  Input,
  Select,
  Button
} = window.YouNewDS_5cb4d2;
const CtI = n => /*#__PURE__*/React.createElement("i", {
  "data-lucide": n
});
function Contact() {
  const rows = [['message-circle', 'WhatsApp', '(11) XXXX-XXXX'], ['mail', 'E-mail', 'contato@youcontabilidade.com.br'], ['map-pin', 'Onde estamos', 'Atendemos todo o Brasil. São Paulo, SP']];
  return /*#__PURE__*/React.createElement("section", {
    className: "i-section",
    id: "contato"
  }, /*#__PURE__*/React.createElement("div", {
    className: "i-container i-contact"
  }, /*#__PURE__*/React.createElement("div", {
    className: "i-contact__info"
  }, /*#__PURE__*/React.createElement("h2", null, "Vamos conversar sobre o seu neg\xF3cio"), /*#__PURE__*/React.createElement("p", null, "Preencha e um especialista entra em contato em at\xE9 1 dia \xFAtil. Sem compromisso e sem enrola\xE7\xE3o."), /*#__PURE__*/React.createElement("div", {
    className: "i-contact__list"
  }, rows.map(([ic, t, v]) => /*#__PURE__*/React.createElement("div", {
    className: "i-contact__row",
    key: t
  }, /*#__PURE__*/React.createElement("span", {
    className: "ic"
  }, CtI(ic)), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("b", null, t), /*#__PURE__*/React.createElement("span", null, v)))))), /*#__PURE__*/React.createElement("form", {
    className: "i-form-dark",
    onSubmit: e => e.preventDefault()
  }, /*#__PURE__*/React.createElement("div", {
    className: "i-form-dark__head"
  }, /*#__PURE__*/React.createElement("h3", null, "Pe\xE7a seu diagn\xF3stico"), /*#__PURE__*/React.createElement("p", null, "Sem compromisso. Um especialista da You responde.")), /*#__PURE__*/React.createElement(Input, {
    label: "Nome",
    placeholder: "Seu nome"
  }), /*#__PURE__*/React.createElement(Input, {
    label: "E-mail",
    type: "email",
    placeholder: "Seu melhor e-mail"
  }), /*#__PURE__*/React.createElement("div", {
    className: "you-field you-field--full"
  }, /*#__PURE__*/React.createElement("label", {
    className: "you-field__label"
  }, "Telefone"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '114px 1fr',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(Select, {
    options: ['BR +55']
  }), /*#__PURE__*/React.createElement(Input, {
    placeholder: "(00) 00000-0000"
  }))), /*#__PURE__*/React.createElement(Input, {
    label: "Empresa",
    placeholder: "Nome da empresa"
  }), /*#__PURE__*/React.createElement(Select, {
    label: "Segmento",
    placeholder: "Selecionar segmento",
    options: ['Marketplace', 'E-commerce próprio', 'Prestador de serviço', 'Comércio ou indústria']
  }), /*#__PURE__*/React.createElement(Select, {
    label: "Faturamento atual",
    placeholder: "Selecionar",
    options: ['Até R$ XX mil', 'R$ XX mil a R$ XX mil', 'Acima de R$ XX mil']
  }), /*#__PURE__*/React.createElement("div", {
    className: "you-field you-field--full"
  }, /*#__PURE__*/React.createElement("label", {
    className: "you-field__label"
  }, "Mensagem (opcional)"), /*#__PURE__*/React.createElement("div", {
    className: "you-field__wrap",
    style: {
      alignItems: 'stretch'
    }
  }, /*#__PURE__*/React.createElement("textarea", {
    className: "you-input",
    rows: 3,
    placeholder: "Conte um pouco sobre o seu neg\xF3cio.",
    style: {
      resize: 'vertical',
      padding: '12px 0',
      fontFamily: 'inherit'
    }
  }))), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    fullWidth: true,
    type: "submit",
    rightIcon: CtI('arrow-right')
  }, "Quero conversar"), /*#__PURE__*/React.createElement("p", {
    className: "i-form-dark__priv"
  }, "Ao enviar, voc\xEA concorda com a nossa Pol\xEDtica de Privacidade. Seus dados n\xE3o ser\xE3o compartilhados."))));
}
Object.assign(window, {
  Contact
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/institutional/instContact.jsx", error: String((e && e.message) || e) }); }

// ui_kits/institutional/instFooter.jsx
try { (() => {
/* You Contabilidade, Institutional: CTA band + footer + whatsapp float */
const {
  Button,
  IconButton
} = window.YouNewDS_5cb4d2;
const FtI = n => /*#__PURE__*/React.createElement("i", {
  "data-lucide": n
});
function CTABand() {
  return /*#__PURE__*/React.createElement("section", {
    className: "i-section i-cta"
  }, /*#__PURE__*/React.createElement("div", {
    className: "i-container i-cta__inner"
  }, /*#__PURE__*/React.createElement("h2", null, "Pronto para ter uma contabilidade que entende de voc\xEA?"), /*#__PURE__*/React.createElement("p", null, "Migra\xE7\xE3o gratuita e sem burocracia. Comece hoje mesmo a pagar menos imposto."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14,
      flexWrap: 'wrap',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "xl",
    href: "#contato",
    rightIcon: FtI('arrow-right')
  }, "Falar com um especialista"), /*#__PURE__*/React.createElement(Button, {
    variant: "outline",
    size: "xl",
    href: "#",
    leftIcon: FtI('message-circle'),
    style: {
      color: '#fff',
      borderColor: 'rgba(255,255,255,.6)'
    }
  }, "WhatsApp"))));
}
function Footer() {
  const social = ['instagram', 'youtube', 'linkedin', 'facebook'];
  const col = (title, links) => /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h5", null, title), /*#__PURE__*/React.createElement("ul", null, links.map(l => /*#__PURE__*/React.createElement("li", {
    key: l
  }, /*#__PURE__*/React.createElement("a", {
    href: "#"
  }, l)))));
  return /*#__PURE__*/React.createElement("footer", {
    className: "i-footer"
  }, /*#__PURE__*/React.createElement("div", {
    className: "i-container"
  }, /*#__PURE__*/React.createElement("div", {
    className: "i-footer__top"
  }, /*#__PURE__*/React.createElement("div", {
    className: "i-footer__brand"
  }, /*#__PURE__*/React.createElement("img", {
    src: window.ASSETS + '/you-logo-white-trim.png',
    alt: "You Contabilidade"
  }), /*#__PURE__*/React.createElement("p", null, "Contabilidade especializada para vendedores de marketplace e empresas. Menos imposto, mais lucro."), /*#__PURE__*/React.createElement("div", {
    className: "i-footer__social"
  }, social.map(s => /*#__PURE__*/React.createElement(IconButton, {
    key: s,
    variant: "outline",
    size: "sm",
    "aria-label": s,
    href: "#",
    icon: FtI(s)
  })))), col('Serviços', ['Abertura de empresa', 'Contabilidade mensal', 'Emissão de notas', 'Planejamento tributário']), col('Empresa', ['Sobre a You', 'Blog', 'Carreiras', 'Trabalhe conosco']), col('Contato', ['WhatsApp', 'Central de ajuda', 'Termos de uso', 'Privacidade'])), /*#__PURE__*/React.createElement("div", {
    className: "i-footer__bottom"
  }, /*#__PURE__*/React.createElement("span", null, "\xA9 2025 You Contabilidade \xB7 CNPJ 00.000.000/0001-00 \xB7 CRC-SP 0.000.000"), /*#__PURE__*/React.createElement("span", null, "Feito no Brasil para quem vende online."))));
}
function WhatsAppFloat() {
  return /*#__PURE__*/React.createElement("div", {
    className: "i-wa"
  }, /*#__PURE__*/React.createElement(IconButton, {
    variant: "primary",
    "aria-label": "Falar no WhatsApp",
    href: "#",
    icon: FtI('message-circle')
  }));
}
Object.assign(window, {
  CTABand,
  Footer,
  WhatsAppFloat
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/institutional/instFooter.jsx", error: String((e && e.message) || e) }); }

// ui_kits/institutional/instHeader.jsx
try { (() => {
/* You Contabilidade, Institutional: header + mobile menu */
const {
  Button,
  IconButton
} = window.YouNewDS_5cb4d2;
const HdI = n => /*#__PURE__*/React.createElement("i", {
  "data-lucide": n
});
function Header({
  onMenu,
  menuOpen
}) {
  return /*#__PURE__*/React.createElement("header", {
    className: "i-header"
  }, /*#__PURE__*/React.createElement("div", {
    className: "i-header__inner"
  }, /*#__PURE__*/React.createElement("a", {
    href: "#top",
    "aria-label": "You Contabilidade"
  }, /*#__PURE__*/React.createElement("img", {
    className: "i-logo",
    src: window.ASSETS + '/you-logo-color-trim.png',
    alt: "You Contabilidade"
  })), /*#__PURE__*/React.createElement("nav", {
    className: "i-nav"
  }, /*#__PURE__*/React.createElement("a", {
    href: "#servicos"
  }, "Servi\xE7os"), /*#__PURE__*/React.createElement("a", {
    href: "#segmentos"
  }, "Segmentos"), /*#__PURE__*/React.createElement("a", {
    href: "#sobre"
  }, "Sobre"), /*#__PURE__*/React.createElement("a", {
    href: "#processo"
  }, "Como trabalhamos"), /*#__PURE__*/React.createElement("a", {
    href: "#contato"
  }, "Contato")), /*#__PURE__*/React.createElement("div", {
    className: "i-header__cta"
  }, /*#__PURE__*/React.createElement(Button, {
    className: "i-hide-sm",
    variant: "ghost",
    size: "sm",
    href: "#",
    pill: false,
    leftIcon: HdI('circle-user')
  }, "\xC1rea do cliente"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "sm",
    href: "#contato"
  }, "Fale conosco"), /*#__PURE__*/React.createElement("span", {
    className: "i-burger"
  }, /*#__PURE__*/React.createElement(IconButton, {
    variant: "soft",
    "aria-label": "Abrir menu",
    onClick: onMenu,
    icon: HdI(menuOpen ? 'x' : 'menu')
  })))));
}
function MobileMenu({
  onClose
}) {
  const links = [['#servicos', 'Serviços'], ['#segmentos', 'Segmentos'], ['#sobre', 'Sobre'], ['#processo', 'Como trabalhamos'], ['#contato', 'Contato']];
  return /*#__PURE__*/React.createElement("div", {
    className: "i-mobile"
  }, links.map(([h, l]) => /*#__PURE__*/React.createElement("a", {
    key: h,
    href: h,
    onClick: onClose
  }, l)), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    href: "#contato",
    fullWidth: true,
    onClick: onClose
  }, "Fale conosco"));
}
Object.assign(window, {
  Header,
  MobileMenu
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/institutional/instHeader.jsx", error: String((e && e.message) || e) }); }

// ui_kits/institutional/instHero.jsx
try { (() => {
/* You Contabilidade, Institutional: hero */
const {
  Button,
  Badge
} = window.YouNewDS_5cb4d2;
const HrI = n => /*#__PURE__*/React.createElement("i", {
  "data-lucide": n
});
function Hero() {
  const creds = [['shield-check', 'CRC ativo e regular'], ['users', '+XXX clientes'], ['star', 'Nota 4,9 no Google']];
  return /*#__PURE__*/React.createElement("section", {
    className: "i-hero",
    id: "top"
  }, /*#__PURE__*/React.createElement("div", {
    className: "i-container i-hero__grid"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Badge, {
    color: "brand",
    variant: "soft",
    leftIcon: HrI('sparkles')
  }, "Contabilidade especializada"), /*#__PURE__*/React.createElement("h1", {
    className: "i-hero__title"
  }, "A contabilidade que ", /*#__PURE__*/React.createElement("em", null, "entende"), " de quem vende online."), /*#__PURE__*/React.createElement("p", {
    className: "i-hero__sub"
  }, "Cuidamos do CNPJ, dos impostos e das obriga\xE7\xF5es de vendedores de marketplace e empresas, com atendimento humano e linguagem que voc\xEA entende."), /*#__PURE__*/React.createElement("div", {
    className: "i-hero__actions"
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    href: "#contato",
    rightIcon: HrI('arrow-right')
  }, "Falar com um especialista"), /*#__PURE__*/React.createElement(Button, {
    variant: "outline",
    size: "lg",
    href: "#servicos"
  }, "Conhecer servi\xE7os")), /*#__PURE__*/React.createElement("div", {
    className: "i-hero__cred"
  }, creds.map(([ic, t]) => /*#__PURE__*/React.createElement("span", {
    className: "i-cred",
    key: t
  }, /*#__PURE__*/React.createElement("span", {
    className: "ic"
  }, HrI(ic)), t)))), /*#__PURE__*/React.createElement("div", {
    className: "i-hero__media"
  }, /*#__PURE__*/React.createElement("image-slot", {
    id: "inst-hero",
    shape: "rect",
    placeholder: "Foto da equipe / escrit\xF3rio You"
  }), /*#__PURE__*/React.createElement("div", {
    className: "i-hero__floatcard"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ic"
  }, HrI('message-circle')), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("b", null, "Atendimento humano"), /*#__PURE__*/React.createElement("span", null, "Fale com seu contador no WhatsApp"))))));
}
Object.assign(window, {
  Hero
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/institutional/instHero.jsx", error: String((e && e.message) || e) }); }

// ui_kits/institutional/instServices.jsx
try { (() => {
/* You Contabilidade, Institutional: services + segments */
const {
  SectionHeading,
  Card
} = window.YouNewDS_5cb4d2;
const SvI = n => /*#__PURE__*/React.createElement("i", {
  "data-lucide": n
});
function Services() {
  const svc = [['building-2', 'Abertura de empresa', 'Abrimos seu CNPJ do zero, no regime certo e sem custo de abertura.'], ['calculator', 'Contabilidade mensal', 'Escrituração, apuração de impostos e balanços sempre em dia.'], ['receipt', 'Emissão de notas', 'NF-e e NFS-e integradas às suas vendas em marketplace e e-commerce.'], ['users', 'Departamento pessoal', 'Admissão, folha, férias e encargos da sua equipe, sem dor de cabeça.'], ['trending-up', 'Planejamento tributário', 'Análise do melhor enquadramento para você pagar menos, dentro da lei.'], ['briefcase', 'Consultoria contábil', 'Um contador de verdade ao seu lado para decisões de crescimento.']];
  return /*#__PURE__*/React.createElement("section", {
    className: "i-section",
    id: "servicos"
  }, /*#__PURE__*/React.createElement("div", {
    className: "i-container"
  }, /*#__PURE__*/React.createElement("div", {
    className: "i-head-wrap"
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    align: "center",
    eyebrow: "Servi\xE7os",
    title: /*#__PURE__*/React.createElement(React.Fragment, null, "Contabilidade completa, ", /*#__PURE__*/React.createElement("em", null, "de ponta a ponta")),
    subtitle: "Tudo que a sua empresa precisa, com um time especializado em neg\xF3cios digitais."
  })), /*#__PURE__*/React.createElement("div", {
    className: "i-grid-3"
  }, svc.map((s, i) => /*#__PURE__*/React.createElement(Card, {
    key: i,
    variant: "outline",
    padding: "lg",
    className: "i-service"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ic"
  }, SvI(s[0])), /*#__PURE__*/React.createElement("h3", null, s[1]), /*#__PURE__*/React.createElement("p", null, s[2]), /*#__PURE__*/React.createElement("a", {
    href: "#contato"
  }, "Saiba mais ", SvI('arrow-right')))))));
}
function Segments() {
  const seg = [['shopping-cart', 'Marketplace', 'Mercado Livre, Shopee, Amazon e Magalu.'], ['store', 'E-commerce', 'Loja própria, Shopify, Nuvemshop e mais.'], ['laptop', 'Prestadores de serviço', 'Profissionais e agências que emitem NFS-e.'], ['factory', 'Comércio e indústria', 'Empresas que querem crescer com segurança.']];
  return /*#__PURE__*/React.createElement("section", {
    className: "i-section i-alt",
    id: "segmentos"
  }, /*#__PURE__*/React.createElement("div", {
    className: "i-container"
  }, /*#__PURE__*/React.createElement("div", {
    className: "i-head-wrap"
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    align: "center",
    eyebrow: "Para quem",
    title: /*#__PURE__*/React.createElement(React.Fragment, null, "Feita para o seu ", /*#__PURE__*/React.createElement("em", null, "tipo de neg\xF3cio"))
  })), /*#__PURE__*/React.createElement("div", {
    className: "i-seg"
  }, seg.map((s, i) => /*#__PURE__*/React.createElement("div", {
    className: "i-segcard",
    key: i
  }, /*#__PURE__*/React.createElement("span", {
    className: "ic"
  }, SvI(s[0])), /*#__PURE__*/React.createElement("h4", null, s[1]), /*#__PURE__*/React.createElement("p", null, s[2]))))));
}
Object.assign(window, {
  Services,
  Segments
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/institutional/instServices.jsx", error: String((e && e.message) || e) }); }

// ui_kits/landing/landingApp.jsx
try { (() => {
/* You Contabilidade, Landing: page composition */
function LandingApp() {
  const [menu, setMenu] = React.useState(false);
  React.useEffect(() => {
    if (window.lucide) window.lucide.createIcons();
  });
  return /*#__PURE__*/React.createElement("div", {
    className: "l-page"
  }, /*#__PURE__*/React.createElement(Header, {
    onMenu: () => setMenu(m => !m),
    menuOpen: menu
  }), menu && /*#__PURE__*/React.createElement(MobileMenu, {
    onClose: () => setMenu(false)
  }), /*#__PURE__*/React.createElement("main", null, /*#__PURE__*/React.createElement(Hero, null), /*#__PURE__*/React.createElement(TrustBar, null), /*#__PURE__*/React.createElement(Problem, null), /*#__PURE__*/React.createElement(Benefits, null), /*#__PURE__*/React.createElement(Steps, null), /*#__PURE__*/React.createElement(Plans, null), /*#__PURE__*/React.createElement(Testimonials, null), /*#__PURE__*/React.createElement(StatsBand, null), /*#__PURE__*/React.createElement(Faq, null), /*#__PURE__*/React.createElement(FinalCTA, null)), /*#__PURE__*/React.createElement(Footer, null), /*#__PURE__*/React.createElement(WhatsAppFloat, null));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(LandingApp, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/landing/landingApp.jsx", error: String((e && e.message) || e) }); }

// ui_kits/landing/landingFooter.jsx
try { (() => {
/* You Contabilidade, Landing: final CTA + footer */
const {
  Button,
  IconButton
} = window.YouNewDS_5cb4d2;
const FtI = n => /*#__PURE__*/React.createElement("i", {
  "data-lucide": n
});
function FinalCTA() {
  return /*#__PURE__*/React.createElement("section", {
    className: "l-section l-final"
  }, /*#__PURE__*/React.createElement("div", {
    className: "l-container l-final__inner"
  }, /*#__PURE__*/React.createElement("h2", null, "Pronto para parar de pagar imposto a mais?"), /*#__PURE__*/React.createElement("p", null, "Fa\xE7a o diagn\xF3stico gratuito e descubra hoje quanto a You pode economizar no seu neg\xF3cio."), /*#__PURE__*/React.createElement("div", {
    className: "l-hero__actions",
    style: {
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "xl",
    href: "#planos",
    rightIcon: FtI('arrow-right')
  }, "Quero meu diagn\xF3stico gr\xE1tis"), /*#__PURE__*/React.createElement(Button, {
    variant: "outline",
    size: "xl",
    href: "#",
    leftIcon: FtI('message-circle')
  }, "Falar no WhatsApp"))));
}
function Footer() {
  const social = ['instagram', 'youtube', 'linkedin', 'facebook'];
  const col = (title, links) => /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h5", null, title), /*#__PURE__*/React.createElement("ul", null, links.map(l => /*#__PURE__*/React.createElement("li", {
    key: l
  }, /*#__PURE__*/React.createElement("a", {
    href: "#"
  }, l)))));
  return /*#__PURE__*/React.createElement("footer", {
    className: "l-footer"
  }, /*#__PURE__*/React.createElement("div", {
    className: "l-container"
  }, /*#__PURE__*/React.createElement("div", {
    className: "l-footer__top"
  }, /*#__PURE__*/React.createElement("div", {
    className: "l-footer__brand"
  }, /*#__PURE__*/React.createElement("img", {
    src: window.ASSETS + '/you-logo-white-trim.png',
    alt: "You Contabilidade"
  }), /*#__PURE__*/React.createElement("p", null, "Contabilidade especializada para vendedores de marketplace e empresas. Menos imposto, mais lucro."), /*#__PURE__*/React.createElement("div", {
    className: "l-footer__social"
  }, social.map(s => /*#__PURE__*/React.createElement(IconButton, {
    key: s,
    variant: "outline",
    size: "sm",
    "aria-label": s,
    href: "#",
    icon: FtI(s)
  })))), col('Empresa', ['Sobre a You', 'Blog', 'Carreiras', 'Contato']), col('Serviços', ['Abertura de CNPJ', 'Simples Nacional', 'Emissão de notas', 'Migração de contador']), col('Ajuda', ['Central de ajuda', 'WhatsApp', 'Termos de uso', 'Privacidade'])), /*#__PURE__*/React.createElement("div", {
    className: "l-footer__bottom"
  }, /*#__PURE__*/React.createElement("span", null, "\xA9 2025 You Contabilidade \xB7 CNPJ 00.000.000/0001-00"), /*#__PURE__*/React.createElement("span", null, "Feito no Brasil para quem vende online."))));
}
Object.assign(window, {
  FinalCTA,
  Footer
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/landing/landingFooter.jsx", error: String((e && e.message) || e) }); }

// ui_kits/landing/landingHeader.jsx
try { (() => {
/* You Contabilidade, Landing: header, mobile menu, WhatsApp float */
const {
  Button,
  IconButton
} = window.YouNewDS_5cb4d2;
const HdI = n => /*#__PURE__*/React.createElement("i", {
  "data-lucide": n
});
function Header({
  onMenu,
  menuOpen
}) {
  const [scrolled, setScrolled] = React.useState(false);
  React.useEffect(() => {
    const h = () => setScrolled(window.scrollY > 8);
    window.addEventListener('scroll', h);
    h();
    return () => window.removeEventListener('scroll', h);
  }, []);
  return /*#__PURE__*/React.createElement("header", {
    className: 'l-header' + (scrolled ? ' scrolled' : '')
  }, /*#__PURE__*/React.createElement("div", {
    className: "l-header__inner"
  }, /*#__PURE__*/React.createElement("a", {
    href: "#top",
    "aria-label": "You Contabilidade"
  }, /*#__PURE__*/React.createElement("img", {
    className: "l-logo",
    src: window.ASSETS + '/you-logo-color-trim.png',
    alt: "You Contabilidade"
  })), /*#__PURE__*/React.createElement("nav", {
    className: "l-nav"
  }, /*#__PURE__*/React.createElement("a", {
    href: "#beneficios"
  }, "Benef\xEDcios"), /*#__PURE__*/React.createElement("a", {
    href: "#como"
  }, "Como funciona"), /*#__PURE__*/React.createElement("a", {
    href: "#planos"
  }, "Planos"), /*#__PURE__*/React.createElement("a", {
    href: "#depoimentos"
  }, "Depoimentos"), /*#__PURE__*/React.createElement("a", {
    href: "#faq"
  }, "FAQ")), /*#__PURE__*/React.createElement("div", {
    className: "l-header__cta"
  }, /*#__PURE__*/React.createElement(Button, {
    className: "l-hide-sm",
    variant: "ghost",
    size: "sm",
    href: "#",
    pill: false,
    leftIcon: HdI('phone')
  }, "(11) XXXX-XXXX"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "sm",
    href: "#planos"
  }, "Quero pagar menos"), /*#__PURE__*/React.createElement("span", {
    className: "l-burger"
  }, /*#__PURE__*/React.createElement(IconButton, {
    variant: "soft",
    "aria-label": "Abrir menu",
    onClick: onMenu,
    icon: HdI(menuOpen ? 'x' : 'menu')
  })))));
}
function MobileMenu({
  onClose
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "l-mobile"
  }, /*#__PURE__*/React.createElement("a", {
    href: "#beneficios",
    onClick: onClose
  }, "Benef\xEDcios"), /*#__PURE__*/React.createElement("a", {
    href: "#como",
    onClick: onClose
  }, "Como funciona"), /*#__PURE__*/React.createElement("a", {
    href: "#planos",
    onClick: onClose
  }, "Planos"), /*#__PURE__*/React.createElement("a", {
    href: "#depoimentos",
    onClick: onClose
  }, "Depoimentos"), /*#__PURE__*/React.createElement("a", {
    href: "#faq",
    onClick: onClose
  }, "FAQ"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    href: "#planos",
    fullWidth: true,
    onClick: onClose
  }, "Quero pagar menos imposto"));
}
function WhatsAppFloat() {
  return /*#__PURE__*/React.createElement("div", {
    className: "l-wa"
  }, /*#__PURE__*/React.createElement(IconButton, {
    variant: "primary",
    "aria-label": "Falar no WhatsApp",
    href: "#",
    icon: HdI('message-circle')
  }));
}
Object.assign(window, {
  Header,
  MobileMenu,
  WhatsAppFloat
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/landing/landingHeader.jsx", error: String((e && e.message) || e) }); }

// ui_kits/landing/landingHero.jsx
try { (() => {
/* You Contabilidade, Landing: hero, hero mock, trust bar */
const {
  Button,
  Badge
} = window.YouNewDS_5cb4d2;
const HrI = n => /*#__PURE__*/React.createElement("i", {
  "data-lucide": n
});
function HeroMock() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      width: '100%',
      maxWidth: 420,
      marginInline: 'auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "l-mock"
  }, /*#__PURE__*/React.createElement("div", {
    className: "l-mock__top"
  }, /*#__PURE__*/React.createElement("div", {
    className: "l-mock__brand"
  }, /*#__PURE__*/React.createElement("img", {
    src: window.ASSETS + '/you-symbol-trim.png',
    alt: ""
  }), "Resumo fiscal"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      fontWeight: 700,
      color: 'var(--success-600)',
      background: 'var(--success-100)',
      padding: '4px 10px',
      borderRadius: 999
    }
  }, "Em dia")), /*#__PURE__*/React.createElement("div", {
    className: "l-mock__hero-num"
  }, /*#__PURE__*/React.createElement("div", {
    className: "n"
  }, "R$ XXX"), /*#__PURE__*/React.createElement("div", {
    className: "c"
  }, "de imposto economizado em julho")), /*#__PURE__*/React.createElement("div", {
    className: "l-mock__row"
  }, /*#__PURE__*/React.createElement("span", null, "Faturamento no m\xEAs"), /*#__PURE__*/React.createElement("b", null, "R$ XX.XXX")), /*#__PURE__*/React.createElement("div", {
    className: "l-mock__row"
  }, /*#__PURE__*/React.createElement("span", null, "Simples Nacional (DAS)"), /*#__PURE__*/React.createElement("b", null, "R$ X.XXX")), /*#__PURE__*/React.createElement("div", {
    className: "l-mock__row",
    style: {
      borderBottom: 'none'
    }
  }, /*#__PURE__*/React.createElement("span", null, "Notas emitidas"), /*#__PURE__*/React.createElement("b", null, "XXX"))), /*#__PURE__*/React.createElement("div", {
    className: "l-badge-float l-badge-float--tl"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ic",
    style: {
      background: 'var(--gradient-brand)'
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "trending-down"
  })), /*#__PURE__*/React.createElement("div", null, "Imposto menor", /*#__PURE__*/React.createElement("small", null, "vs. pessoa f\xEDsica"))), /*#__PURE__*/React.createElement("div", {
    className: "l-badge-float l-badge-float--br"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ic",
    style: {
      background: 'var(--success-500)'
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "check"
  })), /*#__PURE__*/React.createElement("div", null, "CNPJ regular", /*#__PURE__*/React.createElement("small", null, "sem pend\xEAncias"))));
}
function Hero() {
  return /*#__PURE__*/React.createElement("section", {
    className: "l-hero",
    id: "top"
  }, /*#__PURE__*/React.createElement("div", {
    className: "l-container l-hero__grid"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Badge, {
    color: "brand",
    variant: "soft",
    leftIcon: HrI('badge-check')
  }, "Contabilidade para marketplace"), /*#__PURE__*/React.createElement("h1", {
    className: "l-hero__title"
  }, "Pare de pagar imposto ", /*#__PURE__*/React.createElement("em", null, "a mais"), " vendendo online."), /*#__PURE__*/React.createElement("p", {
    className: "l-hero__sub"
  }, "A You cuida do seu CNPJ, das suas notas e dos seus impostos. Voc\xEA foca no que importa: vender mais no Mercado Livre e na Shopee."), /*#__PURE__*/React.createElement("div", {
    className: "l-hero__actions"
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "xl",
    href: "#planos",
    rightIcon: HrI('arrow-right')
  }, "Quero pagar menos imposto"), /*#__PURE__*/React.createElement(Button, {
    variant: "outline",
    size: "xl",
    href: "#",
    leftIcon: HrI('message-circle')
  }, "Falar no WhatsApp")), /*#__PURE__*/React.createElement("div", {
    className: "l-hero__trust"
  }, /*#__PURE__*/React.createElement("div", {
    className: "l-avatars"
  }, /*#__PURE__*/React.createElement("span", null, "CR"), /*#__PURE__*/React.createElement("span", null, "DM"), /*#__PURE__*/React.createElement("span", null, "JP"), /*#__PURE__*/React.createElement("span", null, "+")), /*#__PURE__*/React.createElement("div", {
    className: "l-trust__txt"
  }, /*#__PURE__*/React.createElement("span", {
    className: "l-stars"
  }, "\u2605\u2605\u2605\u2605\u2605"), /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("b", null, "+XXX vendedores"), " j\xE1 economizam com a You"))), /*#__PURE__*/React.createElement("div", {
    className: "l-hero__visual"
  }, /*#__PURE__*/React.createElement(HeroMock, null))));
}
function TrustBar() {
  const names = ['Mercado Livre', 'Shopee', 'Amazon', 'Magalu', 'Shein'];
  return /*#__PURE__*/React.createElement("div", {
    className: "l-trustbar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "l-container l-trustbar__inner"
  }, /*#__PURE__*/React.createElement("span", {
    className: "l-trustbar__lbl"
  }, "Especialistas em quem vende no"), names.map(n => /*#__PURE__*/React.createElement("span", {
    className: "l-mkt",
    key: n
  }, n))));
}
Object.assign(window, {
  Hero,
  TrustBar
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/landing/landingHero.jsx", error: String((e && e.message) || e) }); }

// ui_kits/landing/landingPlans.jsx
try { (() => {
/* You Contabilidade, Landing: pricing plans + guarantee */
const {
  SectionHeading,
  PricingCard,
  Callout
} = window.YouNewDS_5cb4d2;
const PlI = n => /*#__PURE__*/React.createElement("i", {
  "data-lucide": n
});
function Plans() {
  return /*#__PURE__*/React.createElement("section", {
    className: "l-section l-alt",
    id: "planos"
  }, /*#__PURE__*/React.createElement("div", {
    className: "l-container"
  }, /*#__PURE__*/React.createElement("div", {
    className: "l-head-wrap"
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    align: "center",
    eyebrow: "Planos",
    title: /*#__PURE__*/React.createElement(React.Fragment, null, "Escolha o plano e ", /*#__PURE__*/React.createElement("em", null, "comece hoje")),
    subtitle: "Sem fidelidade. Cancele quando quiser. E a migra\xE7\xE3o \xE9 sempre gratuita."
  })), /*#__PURE__*/React.createElement("div", {
    className: "l-plans"
  }, /*#__PURE__*/React.createElement(PricingCard, {
    name: "MEI",
    price: "XX",
    description: "Para quem est\xE1 come\xE7ando a vender",
    features: ['Abertura de MEI grátis', 'Guia DAS todo mês', 'Emissão de notas', 'Suporte por e-mail'],
    ctaLabel: "Come\xE7ar como MEI",
    ctaProps: {
      href: '#'
    }
  }), /*#__PURE__*/React.createElement(PricingCard, {
    featured: true,
    name: "Vendedor",
    price: "XX",
    oldPrice: "XX",
    description: "Para quem j\xE1 fatura no marketplace",
    features: ['Simples Nacional otimizado', 'Notas fiscais ilimitadas', 'Contador no WhatsApp', 'App You + relatórios', 'Migração de CNPJ grátis'],
    ctaLabel: "Assinar agora",
    ctaProps: {
      href: '#'
    }
  }), /*#__PURE__*/React.createElement(PricingCard, {
    name: "Empresa",
    price: "XX",
    description: "Para opera\xE7\xF5es com equipe",
    features: ['Múltiplos CNPJs', 'Folha de pagamento', 'Consultor dedicado', 'Planejamento tributário'],
    ctaLabel: "Falar com vendas",
    ctaProps: {
      href: '#'
    }
  })), /*#__PURE__*/React.createElement("p", {
    className: "l-plans__note"
  }, "Valores promocionais de lan\xE7amento \xB7 Parcelamos no cart\xE3o \xB7 Consulte condi\xE7\xF5es."), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 720,
      marginInline: 'auto',
      marginTop: 32
    }
  }, /*#__PURE__*/React.createElement(Callout, {
    tone: "success",
    icon: PlI('shield-check'),
    title: "Garantia de 7 dias, risco zero"
  }, "Testou e n\xE3o gostou? Devolvemos 100% do valor em at\xE9 7 dias, sem perguntas e sem letras mi\xFAdas."))));
}
Object.assign(window, {
  Plans
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/landing/landingPlans.jsx", error: String((e && e.message) || e) }); }

// ui_kits/landing/landingProof.jsx
try { (() => {
/* You Contabilidade, Landing: testimonials, stats band, FAQ */
const {
  SectionHeading,
  Testimonial,
  Stat,
  Accordion
} = window.YouNewDS_5cb4d2;
function Testimonials() {
  return /*#__PURE__*/React.createElement("section", {
    className: "l-section",
    id: "depoimentos"
  }, /*#__PURE__*/React.createElement("div", {
    className: "l-container"
  }, /*#__PURE__*/React.createElement("div", {
    className: "l-head-wrap"
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    align: "center",
    eyebrow: "Depoimentos",
    title: /*#__PURE__*/React.createElement(React.Fragment, null, "Quem vende com a You ", /*#__PURE__*/React.createElement("em", null, "economiza de verdade")),
    subtitle: "Vendedores de todo o Brasil j\xE1 trocaram o contador comum pela You."
  })), /*#__PURE__*/React.createElement("div", {
    className: "l-testis"
  }, /*#__PURE__*/React.createElement(Testimonial, {
    rating: 5,
    quote: "Sa\xED do MEI pro Simples com a You e todo m\xEAs pago menos imposto. Foi a melhor decis\xE3o do ano.",
    name: "Camila Rocha",
    role: "Loja no Mercado Livre"
  }), /*#__PURE__*/React.createElement(Testimonial, {
    rating: 5,
    quote: "Eles entendem de marketplace de verdade. Repasse, antecipa\xE7\xE3o, nota... resolveram tudo que meu contador antigo travava.",
    name: "Diego Martins",
    role: "Seller na Shopee"
  }), /*#__PURE__*/React.createElement(Testimonial, {
    rating: 5,
    quote: "A migra\xE7\xE3o foi num passe de m\xE1gica. N\xE3o fiz nada, cuidaram de tudo. Hoje \xE9 s\xF3 vender e receber o resumo pronto.",
    name: "Jo\xE3o Paulo Reis",
    role: "Eletr\xF4nicos \xB7 ML e Amazon"
  }))));
}
function StatsBand() {
  return /*#__PURE__*/React.createElement("section", {
    className: "l-section--tight l-band"
  }, /*#__PURE__*/React.createElement("div", {
    className: "l-container l-band__grid"
  }, /*#__PURE__*/React.createElement(Stat, {
    onDark: true,
    value: "+XXX",
    label: "vendedores atendidos"
  }), /*#__PURE__*/React.createElement(Stat, {
    onDark: true,
    value: "R$ XXM",
    label: "em impostos economizados"
  }), /*#__PURE__*/React.createElement(Stat, {
    onDark: true,
    value: "X,X\u2605",
    label: "avalia\xE7\xE3o no Google"
  }), /*#__PURE__*/React.createElement(Stat, {
    onDark: true,
    value: "X dias",
    label: "para migrar seu CNPJ"
  })));
}
function Faq() {
  const items = [{
    question: 'Preciso já ter CNPJ para contratar?',
    answer: 'Não. A You abre o seu CNPJ de graça, já otimizado para quem vende em marketplace. Se você já tem, fazemos a migração sem custo.'
  }, {
    question: 'Vocês atendem MEI?',
    answer: 'Sim. Atendemos do MEI ao Simples Nacional e ao Lucro Presumido. No diagnóstico indicamos o enquadramento em que você paga menos imposto.'
  }, {
    question: 'Quanto tempo leva para migrar meu contador?',
    answer: 'Em média 7 dias úteis. Cuidamos de toda a papelada com o contador anterior e você não fica descoberto em nenhum momento.'
  }, {
    question: 'A You emite as minhas notas fiscais?',
    answer: 'Sim. Configuramos e emitimos NF-e e NFS-e, integradas às suas vendas. Chega de planilha e de emitir nota na mão.'
  }, {
    question: 'Tem fidelidade ou multa de cancelamento?',
    answer: 'Nenhuma. Você pode cancelar quando quiser. E nos 7 primeiros dias devolvemos 100% do valor se não gostar.'
  }, {
    question: 'Como funciona o suporte?',
    answer: 'Você fala direto com um contador que entende de marketplace, pelo WhatsApp. Nada de robô ou de fila interminável.'
  }];
  return /*#__PURE__*/React.createElement("section", {
    className: "l-section l-alt",
    id: "faq"
  }, /*#__PURE__*/React.createElement("div", {
    className: "l-container"
  }, /*#__PURE__*/React.createElement("div", {
    className: "l-head-wrap"
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    align: "center",
    eyebrow: "D\xFAvidas",
    title: /*#__PURE__*/React.createElement(React.Fragment, null, "Perguntas ", /*#__PURE__*/React.createElement("em", null, "frequentes"))
  })), /*#__PURE__*/React.createElement("div", {
    className: "l-faq"
  }, /*#__PURE__*/React.createElement(Accordion, {
    defaultOpen: [0],
    items: items
  }))));
}
Object.assign(window, {
  Testimonials,
  StatsBand,
  Faq
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/landing/landingProof.jsx", error: String((e && e.message) || e) }); }

// ui_kits/landing/landingValue.jsx
try { (() => {
/* You Contabilidade, Landing: problem, benefits, steps */
const {
  SectionHeading,
  Card
} = window.YouNewDS_5cb4d2;
const VI = n => /*#__PURE__*/React.createElement("i", {
  "data-lucide": n
});
function Problem() {
  const pains = [['triangle-alert', 'Imposto como pessoa física', 'Vendendo no CPF você paga até 27,5% de IR. No CNPJ certo, paga muito menos.'], ['file-warning', 'Medo da malha fina', 'Movimentação alta sem CNPJ acende alerta na Receita. A gente te deixa 100% regular.'], ['user-x', 'Contador que não entende marketplace', 'Repasse, tarifa, antecipação... contador comum se perde. A You é especialista.'], ['alarm-clock', 'Prazo e DAS confusos', 'Perdeu o prazo, veio multa. A You cuida de tudo e te avisa sempre antes.']];
  return /*#__PURE__*/React.createElement("section", {
    className: "l-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "l-container"
  }, /*#__PURE__*/React.createElement("div", {
    className: "l-head-wrap"
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "O problema",
    title: /*#__PURE__*/React.createElement(React.Fragment, null, "Vender \xE9 f\xE1cil. O ", /*#__PURE__*/React.createElement("em", null, "imposto"), " \xE9 que complica."),
    subtitle: "Quem vende em marketplace tem dores que contador comum simplesmente n\xE3o resolve."
  })), /*#__PURE__*/React.createElement("div", {
    className: "l-problem__grid"
  }, pains.map((p, i) => /*#__PURE__*/React.createElement("div", {
    className: "l-pain",
    key: i
  }, /*#__PURE__*/React.createElement("span", {
    className: "ic"
  }, VI(p[0])), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h4", null, p[1]), /*#__PURE__*/React.createElement("p", null, p[2])))))));
}
function Benefits() {
  const bens = [['calculator', 'Imposto sob medida', 'Enquadramos você no regime que paga menos, MEI, Simples ou Presumido.'], ['receipt', 'Notas no automático', 'Emissão de NF-e e NFS-e integrada às suas vendas, sem planilha e sem dor de cabeça.'], ['message-circle', 'Contador no WhatsApp', 'Fala com um humano que entende de marketplace, no horário que der pra você.'], ['shield-check', 'Sem multa, sem susto', 'Cuidamos de todos os prazos e obrigações. Você nunca mais perde nada.'], ['rocket', 'Migração gratuita', 'Trazemos seu CNPJ de outro contador sem custo e sem burocracia nenhuma.'], ['chart-column', 'Visão do seu negócio', 'Relatórios simples de faturamento, imposto e lucro direto no app da You.']];
  return /*#__PURE__*/React.createElement("section", {
    className: "l-section l-alt",
    id: "beneficios"
  }, /*#__PURE__*/React.createElement("div", {
    className: "l-container"
  }, /*#__PURE__*/React.createElement("div", {
    className: "l-head-wrap"
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    align: "center",
    eyebrow: "Por que a You",
    title: /*#__PURE__*/React.createElement(React.Fragment, null, "Tudo que o seu CNPJ precisa, ", /*#__PURE__*/React.createElement("em", null, "num lugar s\xF3")),
    subtitle: "Contabilidade completa, feita para quem vende online."
  })), /*#__PURE__*/React.createElement("div", {
    className: "l-grid-3"
  }, bens.map((b, i) => /*#__PURE__*/React.createElement(Card, {
    key: i,
    variant: "elevated",
    padding: "lg",
    hoverable: true,
    className: "l-benefit"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ic"
  }, VI(b[0])), /*#__PURE__*/React.createElement("h3", null, b[1]), /*#__PURE__*/React.createElement("p", null, b[2]))))));
}
function Steps() {
  const steps = [['Diagnóstico grátis', 'Analisamos suas vendas e mostramos, na hora, quanto você pode economizar de imposto.'], ['A gente migra tudo', 'Abrimos ou trazemos seu CNPJ e configuramos as notas. Você literalmente não faz nada.'], ['Você vende tranquilo', 'Cuidamos de imposto, nota e prazo todo mês. Você foca só em crescer.']];
  return /*#__PURE__*/React.createElement("section", {
    className: "l-section",
    id: "como"
  }, /*#__PURE__*/React.createElement("div", {
    className: "l-container"
  }, /*#__PURE__*/React.createElement("div", {
    className: "l-head-wrap"
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    align: "center",
    eyebrow: "Como funciona",
    title: /*#__PURE__*/React.createElement(React.Fragment, null, "Comece a pagar menos em ", /*#__PURE__*/React.createElement("em", null, "3 passos")),
    subtitle: "Simples, r\xE1pido e sem burocracia, do jeito que deveria ser."
  })), /*#__PURE__*/React.createElement("div", {
    className: "l-steps"
  }, steps.map((s, i) => /*#__PURE__*/React.createElement("div", {
    className: "l-step",
    key: i
  }, /*#__PURE__*/React.createElement("div", {
    className: "l-step__n"
  }, i + 1), /*#__PURE__*/React.createElement("h3", null, s[0]), /*#__PURE__*/React.createElement("p", null, s[1]))))));
}
Object.assign(window, {
  Problem,
  Benefits,
  Steps
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/landing/landingValue.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Accordion = __ds_scope.Accordion;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.SectionHeading = __ds_scope.SectionHeading;

__ds_ns.Callout = __ds_scope.Callout;

__ds_ns.PricingCard = __ds_scope.PricingCard;

__ds_ns.Quote = __ds_scope.Quote;

__ds_ns.Stat = __ds_scope.Stat;

__ds_ns.Testimonial = __ds_scope.Testimonial;

})();
