# You Contabilidade, Design System

Design system **de web** para a **You Contabilidade**: contabilidade brasileira para vendedores de marketplace (Mercado Livre e Shopee) e empresas. Cobre tokens, componentes de interface e telas completas para **páginas de venda de tráfego pago** e **páginas institucionais**.

> Direção: página de venda **agressiva e de alta conversão**, sempre dentro da **marca laranja** da You (`#FE4901` + `#FF9200`). Referências de estilo podem chegar como imagens, a **cor é sempre a paleta laranja da You**, nunca a das referências.

**Este NÃO é um sistema de slides nem de carrossel.** É um kit de web (tokens + componentes + UI kits).

---

## Fontes recebidas
- **Logos** (4 PNGs, fornecidos pelo usuário), copiados e recortados em `assets/`:
  - `you-logo-color-trim.png`, lockup principal “you contabilidade” (laranja, para fundos claros)
  - `you-logo-white-trim.png`, versão reversa (branca, para fundos escuros/laranja)
  - `you-symbol-trim.png`, o símbolo “donut” (o “o” do logo; âmbar + vermelho-laranja)
  - `you-badge-trim.png`, ícone circular laranja com “you” (app icon / avatar / favicon)
  - Originais 1080×1080 preservados: `you-logo-color.png`, `you-logo-white.png`, `you-symbol.png`, `you-badge.png`
- **Briefing textual** do usuário (contexto da empresa e direção de arte).
- Sem codebase, sem Figma, sem decks. Sistema construído a partir da marca (logos + briefing).

---

## Fundamentos de conteúdo (Content Fundamentals)
Como a You escreve:
- **Idioma:** português do Brasil, informal-profissional. Sempre trata o leitor por **“você”** e a empresa por **“a gente” / “a You”** (1ª pessoa do plural). Ex.: *“A gente cuida do imposto; você foca em vender.”*
- **Tom:** direto, confiante e acolhedor. Vende com clareza, não com jargão. Traduz termos fiscais (DAS, Simples, NF-e) para benefícios concretos (“pagar menos”, “sem multa”, “sem susto”).
- **Foco no benefício, não no recurso:** *“Notas no automático”* > *“Emissor de NF-e integrado”*. Sempre conecta ao dinheiro do cliente (menos imposto, mais lucro).
- **Casing:** títulos em **sentence case** (só a 1ª maiúscula), nunca Title Case. Eyebrows/kickers e labels de botão-etiqueta em **CAIXA ALTA** com tracking largo (ex.: `PARA QUEM VENDE ONLINE`, `VAGAS LIMITADAS`). Preços com **R$** e números tabulares.
- **Headlines:** curtas, com **uma palavra em destaque laranja** (via `<em>`). Ex.: *“Menos imposto, **mais lucro**.”* / *“Pare de pagar imposto **a mais**.”*
- **Gatilhos de conversão (com moderação e honestidade):** urgência (“últimas vagas”), prova social (“+2.500 vendedores”), reversão de risco (“garantia de 7 dias”), gratuidade (“diagnóstico grátis”, “migração grátis”). Nunca promessa mirabolante, é uma contabilidade (confiança importa).
- **Emoji:** evitar. A marca não usa emoji na interface. Ícones são **Lucide** (ver Iconografia).
- **Vibe:** “o contador que fala a sua língua e entende de quem vende online”.

Exemplos de copy no sistema: heros, CTAs (“Quero pagar menos imposto”, “Falar no WhatsApp”), FAQ e depoimentos nas UI kits (`ui_kits/`).

---

## Fundamentos visuais (Visual Foundations)
- **Cor:** laranja é a marca inteira. Primária **`#FE4901`** (`--brand-orange`) para CTA, blocos, destaques e números; **`#FF9200`** (`--brand-orange-2`) **só como acento e fim de degradê, nunca carrega texto**. Laranja como texto/link no claro usa **`--orange-text` `#D43D00`** (AA), nunca o `#FE4901` puro. **REGRA de contraste:** texto e label sobre laranja são **escuros** (`--text-on-orange`); branco sobre laranja só em display grande (≥24px negrito). O **degradê** `--brand-gradient` (90°) aparece **só em número/frase de destaque** via `background-clip:text`, nunca em botão/bloco. Neutros são **frios** (zinc), ancorados no `--ink` `#111114`. Verde/vermelho/âmbar só uso funcional em formulário.
- **Tipografia:** display **Clash Display** (600/700) para títulos, herói e números gigantes; corpo, apoio, labels e botões em **Geist** (400/500/600). **Nunca** Inter/Roboto/Arial/system em título. Títulos sentence case, tracking `-0.02em`; eyebrows em caixa alta (`--ls-label` 0.14em) com ponto laranja antes.
- **Escala & espaço:** grid base 4/8 (`--space-1`…`--space-10`). Seções respiram: `--section-y` = `clamp(56px, 10vw, 128px)`. Container 1200px, parágrafo máx. 680px (`--measure`).
- **Cantos (radii):** **apenas dois**, `--radius-md` **14px** em tudo (inputs, cards, caixas, badges) e `--radius-pill` **999px** exclusivo do botão principal/CTA. `--radius-circle` para avatar/ícone redondo. Nada de canto reto nem de valor fora desses.
- **Cards:** raio 14px, **sombra neutra sutil** (`--shadow-md`) ou borda fina (`--border`). Variantes clara (`--surface`) e escura (`--ink`). Em grid, **variação intencional**, um card escuro quebrando a linha ou um em destaque; nunca todos idênticos.
- **Sombras:** sistema **neutro** (`sm`/`md`/`lg`) em `rgba(17,17,20,…)`. **Nunca** brilho/glow laranja, fica amador; sombra é sempre neutra.
- **Fundos:** branco e `--surface` em seções alternadas; **seção escura** (`--ink`) de contraste como âncora; bloco/faixa **laranja** (texto escuro) para destaque e CTA final. Laranja é **bloco e acento com função, nunca parede** saturada que mata o contraste.
- **Imagens:** fotos reais entram por `image-slot` (ver UI kit institucional), vibe quente e humana (equipe, escritório, vendedores). Nunca desenhamos ilustrações em SVG à mão.
- **Movimento:** transições **140-200ms ease-out** (`--dur-fast/base/slow`). **Sem bounce/spring.** Hover, focus-visible e active em tudo interativo; press = leve `translateY(1px)`. Respeita `prefers-reduced-motion`. Sem animações decorativas infinitas.
- **Foco:** anel `--ring-focus` (**2px, offset 2px**, cor `--focus-ring` `#D43D00`) em qualquer elemento interativo (WCAG AA).
- **Transparência/blur:** headers fixos usam fundo branco translúcido + `backdrop-filter` (`--blur-md`). Overlays usam `--overlay`.
- **Links:** `--link` (`--orange-text` `#D43D00`), hover `--ink`, definidos no `base.css`.

---

## Iconografia (Iconography)
- **Biblioteca:** **[Lucide](https://lucide.dev)**, traço **1.5**, `currentColor`, cantos arredondados. É o único sistema de ícones da marca. Sem emoji na interface.
- **Substituição sinalizada:** a You não forneceu um set de ícones próprio; **Lucide é uma substituição** (o mais próximo em peso/estilo). Trocar por um set oficial se a marca vier a ter um.
- **Como usar:** via CDN UMD (`https://unpkg.com/lucide@0.454.0/...`). Coloque `<i data-lucide="nome"></i>` e chame `lucide.createIcons()` após o render (as UI kits fazem isso num `useEffect`). Componentes recebem ícones como `ReactNode` (props `leftIcon`, `rightIcon`, `icon`), são agnósticos à biblioteca.
- **SVGs embutidos:** poucos glifos universais são inline nos componentes (check do Checkbox/PricingCard, chevron do Select/Accordion, estrela do Testimonial), são paths do próprio Lucide, para o componente não depender do CDN.
- **Marca:** o **símbolo donut** (`assets/you-symbol-trim.png`) e o **badge** circular funcionam como ícone/avatar da marca. **Emoji não é usado.** Estrelas de avaliação usam o ícone de estrela (não o caractere ★, exceto em micro-labels de texto).

---

## Índice / manifesto
**Raiz**
- `styles.css`, ponto de entrada único do CSS (só `@import`s). Consumidores linkam **este** arquivo.
- `readme.md`, este guia.
- `SKILL.md`, skill portável (Claude Code / Agent Skills).

**`tokens/`** (importados por `styles.css`)
- `fonts.css` (Clash Display via Fontshare + Geist via Google Fonts) · `colors.css` · `typography.css` · `spacing.css` · `effects.css` · `base.css`

**`assets/`**, logos color/white, símbolo, badge (versões `-trim` recortadas + originais 1080²).

**`components/`** (16 componentes React · use via `window.YouNewDS_5cb4d2`)
- `core/`, **Button**, **IconButton**, **Badge**
- `forms/`, **Input**, **Select**, **Checkbox**, **Radio**, **Switch**
- `layout/`, **Card**, **SectionHeading**, **Accordion**
- `marketing/`, **PricingCard**, **Stat**, **Testimonial**, **Callout**, **Quote**
- cada pasta tem `.jsx` + `.d.ts` + `.prompt.md` + um card `@dsCard` de demonstração.

**`ui_kits/`** (telas completas que compõem os componentes)
- `landing/`, **página de venda / tráfego pago** (hero, prova, planos, garantia, depoimentos, FAQ, CTA). Entrada: `index.html`.
- `institutional/`, **site institucional** (hero, serviços, segmentos, sobre, processo, contato com formulário). Entrada: `index.html`. Usa `image-slot` para fotos reais.

**`guidelines/`**, 20 cards de especímen (grupos Brand, Colors, Type, Spacing, Effects) da aba Design System.

---

## Notas & substituições
- **Fontes:** **Clash Display** (títulos, via **Fontshare**) + **Geist** (corpo, via **Google Fonts**), carregadas em `tokens/fonts.css`, conforme especificado pela You. Se a licença da Clash Display exigir self-host, baixe os `.woff2` em `assets/fonts/` e troque o `@import` por `@font-face` locais.
- **Ícones:** Lucide como substituição (ver Iconografia).
- **Logos de marketplaces** (Mercado Livre, Shopee, etc.) aparecem só como **texto nominativo**, marcas de terceiros não foram redesenhadas nem reproduzidas.
- **Namespace do bundle:** `window.YouNewDS_5cb4d2` (gerado pelo compilador).
