# Catálogo Mestre de Identidade Visual

Documento base para construir, do zero, a identidade visual completa de um sistema (este ou qualquer sistema futuro), junto com um agente de design.

## Como usar este documento

Este NÃO é um retrato de nenhum sistema existente. É uma lista de **tudo que existe de categoria e de variante possível** numa interface, pra você não esquecer nada na hora de decidir o visual novo. Pra cada item, você e o outro agente decidem: usamos ou não, e como fica.

Cada linha é uma casinha pra marcar quando a decisão for tomada. Sugestão de uso: percorrer seção por seção com o agente de design, decidir o valor de cada item, e anotar a decisão do lado (cor exata, medida, nome do efeito escolhido).

```
[ ] Item ainda em aberto
[x] Item já decidido -> anotar aqui a decisão
```

Ordem sugerida pra decidir: primeiro a seção 1 (Fundamentos), porque tudo o resto é construído em cima dela. Só depois entrar em botão, campo, lista etc.

---

## 1. Fundamentos (a base de tudo)

Tudo nas seções seguintes é feito a partir das decisões desta seção. Mudar um fundamento muda o sistema inteiro de uma vez.

### 1.1 Cor

- [ ] Cor de marca principal (a cor que identifica o sistema)
- [ ] Variações da cor de marca: mais clara, mais escura (pra hover, fundo suave, etc.)
- [ ] Cor de marca secundária (se existir uma segunda cor de identidade)
- [ ] Escala de neutros (do branco ao preto, passando por cinzas): quantos degraus, e se o cinza puxa pra algum tom (azulado, amarelado, etc.) ou é neutro puro
- [ ] Cor de sucesso (confirmação, positivo)
- [ ] Cor de erro/perigo (falha, ação destrutiva)
- [ ] Cor de aviso/atenção
- [ ] Cor de informação/neutro informativo
- [ ] Para cada cor semântica acima: versão pra texto, versão pra fundo suave, versão pra borda
- [ ] Cor de fundo da página (camada mais no fundo)
- [ ] Cor de fundo de um elemento elevado (card, painel)
- [ ] Cor de fundo de um elemento sobreposto (modal, menu flutuante)
- [ ] Cor de texto principal
- [ ] Cor de texto secundário (menos importância)
- [ ] Cor de texto terciário/apagado (desabilitado, legenda)
- [ ] Cor de texto sobre um fundo colorido/escuro (texto invertido)
- [ ] Cor de borda padrão
- [ ] Cor de borda em destaque/foco
- [ ] Cor de divisor (linha fina que separa seções)
- [ ] Anel de foco (a cor/contorno que aparece ao navegar pelo teclado)
- [ ] Opacidade padrão pra estado desabilitado
- [ ] Opacidade/transparência de camadas sobrepostas (fundo escurecido atrás de um modal)
- [ ] Todas as cores acima repetidas para o tema escuro
- [ ] Checagem de contraste mínimo entre texto e fundo, em cada combinação usada

### 1.2 Tipografia

- [ ] Fonte de destaque/título (a que dá personalidade)
- [ ] Fonte de corpo de texto (a que carrega o volume de leitura)
- [ ] Fonte para números/dados/código (monoespaçada, opcional)
- [ ] Fonte alternativa de reserva, caso a principal não carregue
- [ ] Escala de tamanhos: do menor texto (legenda) até o maior título, com todos os degraus intermediários
- [ ] Peso fino
- [ ] Peso regular
- [ ] Peso médio
- [ ] Peso semi-negrito
- [ ] Peso negrito
- [ ] Peso extra-negrito
- [ ] Estilo itálico (quando usar, se usar)
- [ ] Altura de linha compacta (títulos, uma linha)
- [ ] Altura de linha normal (parágrafo)
- [ ] Altura de linha espaçosa (texto longo, leitura confortável)
- [ ] Espaçamento entre letras apertado (títulos grandes)
- [ ] Espaçamento entre letras normal
- [ ] Espaçamento entre letras aberto (rótulos em maiúsculas, "eyebrows")
- [ ] Decoração: sublinhado (link, quando aparece)
- [ ] Decoração: tachado (item concluído, cancelado)
- [ ] Transformação: texto normal
- [ ] Transformação: TUDO EM MAIÚSCULO (pra que tipo de rótulo)
- [ ] Transformação: Primeira Letra Maiúscula
- [ ] Alinhamento: esquerda, centro, direita, justificado, e quando usar cada um
- [ ] Texto que estoura o espaço: corta com reticências numa linha, corta em várias linhas, ou rola
- [ ] Números alinhados em coluna (mesma largura pra cada dígito) vs números de largura variável

### 1.3 Espaçamento e grade

- [ ] Unidade base de espaçamento (o "tijolo" a partir do qual tudo é múltiplo)
- [ ] Escala de espaçamento completa (do menor respiro até o maior vão entre seções)
- [ ] Espaçamento interno padrão de um botão
- [ ] Espaçamento interno padrão de um card
- [ ] Espaçamento interno padrão de um campo de formulário
- [ ] Espaçamento entre itens de uma lista
- [ ] Espaçamento entre seções de uma página
- [ ] Densidade "compacta" (tudo mais junto, pra tela cheia de dado)
- [ ] Densidade "confortável" (mais respiro, uso comum)
- [ ] Densidade "espaçosa" (telas de apresentação, poucas coisas)
- [ ] Número de colunas da grade em telas grandes
- [ ] Número de colunas da grade em tablet
- [ ] Número de colunas da grade em celular
- [ ] Pontos de quebra (a partir de qual largura de tela o layout muda)
- [ ] Largura máxima do conteúdo (pra não esticar demais em tela muito larga)
- [ ] Espaço nas bordas da tela (margem externa) em cada tamanho de tela

### 1.4 Bordas e cantos (raio)

- [ ] Canto reto (sem nenhum arredondamento) e onde usar
- [ ] Canto levemente arredondado e onde usar
- [ ] Canto arredondado médio e onde usar
- [ ] Canto bastante arredondado e onde usar
- [ ] Canto totalmente arredondado / formato cápsula (pill) e onde usar
- [ ] Formato circular perfeito (avatar, botão só com ícone) e onde usar
- [ ] Espessura de borda: nenhuma
- [ ] Espessura de borda: fina
- [ ] Espessura de borda: média
- [ ] Espessura de borda: grossa (destaque forte)
- [ ] Estilo de borda: sólida
- [ ] Estilo de borda: tracejada (área de soltar arquivo, por exemplo)
- [ ] Estilo de borda: pontilhada
- [ ] Estilo de borda: dupla
- [ ] Borda só de um lado (por exemplo, uma faixa colorida de destaque num card)

### 1.5 Sombra e elevação

- [ ] Nível 0: totalmente plano, sem sombra
- [ ] Nível 1: sombra bem sutil (elemento que só se separa levemente do fundo)
- [ ] Nível 2: sombra média (card comum)
- [ ] Nível 3: sombra alta (menu flutuante, dropdown)
- [ ] Nível 4: sombra muito alta (modal, janela em primeiro plano)
- [ ] Sombra colorida (na cor da marca, pra destaque especial)
- [ ] Brilho/glow ao redor de um elemento (destaque, notificação)
- [ ] Sombra interna (efeito de "afundado", usado em campo de texto ou barra de progresso)
- [ ] Como a sombra muda no tema escuro (geralmente precisa ficar mais sutil ou virar um brilho, não uma sombra escura)

### 1.6 Ícones

- [ ] Estilo de traço fino (linha)
- [ ] Estilo de traço médio
- [ ] Estilo preenchido (sólido)
- [ ] Estilo duotone (dois tons na mesma forma)
- [ ] Tamanho pequeno (dentro de texto, ao lado de rótulo)
- [ ] Tamanho médio (padrão, dentro de botão)
- [ ] Tamanho grande (ilustrativo, destaque)
- [ ] Ícone sozinho (autônomo, clicável)
- [ ] Ícone dentro de botão (antes do texto, depois do texto, ou sozinho)
- [ ] Ícone dentro de campo de formulário
- [ ] Ícone como indicador de status (bolinha colorida, cadeado, estrela)
- [ ] Ícone animado (girando como carregamento, marcando como confirmado)

### 1.7 Movimento (fundamentos)

- [ ] Duração rápida (microinteração, hover)
- [ ] Duração média (abrir/fechar um painel)
- [ ] Duração lenta (transição de página inteira)
- [ ] Curva suave de entrada (começa devagar, acelera)
- [ ] Curva suave de saída (começa rápido, desacelera)
- [ ] Curva linear (sem aceleração, uso raro)
- [ ] Curva com leve solavanco/mola (dá vida, uso com moderação)
- [ ] Regra pra quando o usuário pede "reduzir movimento": tudo isso precisa ter versão sem animação

---

## 2. Botões

Todo formato, todo peso visual, todo tamanho e todo estado que um botão pode assumir.

### 2.1 Formato do contorno

- [ ] Retangular de cantos retos
- [ ] Retangular levemente arredondado
- [ ] Retangular bem arredondado
- [ ] Formato cápsula (pill, laterais totalmente redondas)
- [ ] Quadrado (só ícone, largura igual à altura)
- [ ] Circular (só ícone, cantos 100% redondos)

### 2.2 Peso visual (hierarquia)

- [ ] Primário: preenchido com a cor de marca, mais chamativo, um por tela/seção
- [ ] Secundário: contornado (borda visível, fundo vazio ou muito suave)
- [ ] Terciário/suave: fundo levemente colorido, sem borda forte
- [ ] Fantasma (ghost): sem fundo nem borda, só texto/ícone, ganha fundo ao passar o mouse
- [ ] Link: parece texto sublinhado, sem caixa ao redor
- [ ] Destrutivo/perigo: cor de alerta, pra ação que apaga ou cancela algo importante

### 2.3 Tamanho

- [ ] Extra pequeno
- [ ] Pequeno
- [ ] Médio (padrão)
- [ ] Grande
- [ ] Extra grande (chamada de destaque)

### 2.4 Conteúdo interno

- [ ] Só texto
- [ ] Ícone à esquerda do texto
- [ ] Ícone à direita do texto
- [ ] Só ícone (sem texto nenhum)
- [ ] Com contador/badge (número pequeno no canto)
- [ ] Com seta de abrir menu (dropdown embutido)
- [ ] Com indicador de carregando (o texto some, aparece um giro)

### 2.5 Estado

- [ ] Padrão/repouso
- [ ] Ao passar o mouse (hover)
- [ ] Pressionado/ativo (o instante do clique)
- [ ] Focado por teclado (contorno visível, sem precisar do mouse)
- [ ] Desabilitado (não clicável, visual apagado)
- [ ] Carregando (ação em andamento, botão trava)
- [ ] Sucesso momentâneo (vira verde/check por um instante após confirmar)
- [ ] Erro momentâneo (treme ou fica vermelho por um instante)

### 2.6 Agrupamento e variações especiais

- [ ] Grupo de botões segmentados (vários grudados, um selecionado por vez)
- [ ] Botão dividido (ação principal + seta separada com mais opções)
- [ ] Botão flutuante (FAB: circular, flutua sobre o conteúdo, ação principal da tela)
- [ ] Botão de alternância (toggle: liga/desliga, dois estados visuais)
- [ ] Botão largura total (ocupa toda a largura do contêiner, comum em formulário mobile)
- [ ] Botão só com sublinhado ao passar o mouse (uso discreto)

---

## 3. Campos e formulários

### 3.1 Tipos de campo

- [ ] Campo de texto de uma linha
- [ ] Campo de texto de várias linhas (textarea)
- [ ] Seletor simples (select/dropdown de uma escolha)
- [ ] Campo com busca e sugestão (autocomplete/combobox)
- [ ] Caixa de marcar (checkbox)
- [ ] Botão de opção única (radio)
- [ ] Alternador liga/desliga (switch)
- [ ] Controle deslizante (slider) de valor único
- [ ] Controle deslizante de faixa (dois valores, mínimo e máximo)
- [ ] Seletor de data
- [ ] Seletor de hora
- [ ] Seletor de data e hora junto
- [ ] Campo de subir arquivo (upload), com área de arrastar-soltar
- [ ] Campo numérico com botões de mais/menos (stepper)
- [ ] Campo com máscara (telefone, CPF/CNPJ, valor em dinheiro)
- [ ] Campo de busca (com ícone de lupa, botão de limpar)
- [ ] Campo de senha (com opção de mostrar/esconder)
- [ ] Campo de código (vários quadradinhos, um dígito em cada, tipo confirmação por SMS)

### 3.2 Rótulo e ajuda

- [ ] Rótulo fixo acima do campo
- [ ] Rótulo flutuante (começa dentro do campo, sobe quando o usuário digita)
- [ ] Texto de exemplo (placeholder) dentro do campo vazio
- [ ] Texto de ajuda abaixo do campo
- [ ] Indicação de campo obrigatório
- [ ] Contador de caracteres (usados / limite)

### 3.3 Estado do campo

- [ ] Padrão/vazio
- [ ] Em foco (o usuário está digitando ali)
- [ ] Preenchido
- [ ] Com erro (borda e mensagem vermelha, explicando o que corrigir)
- [ ] Com sucesso/validado (borda e ícone verde)
- [ ] Desabilitado
- [ ] Somente leitura (mostra valor, não deixa editar)
- [ ] Carregando (aguardando validação ou busca)

### 3.4 Agrupamento

- [ ] Campos lado a lado numa mesma linha
- [ ] Grupo de campos com um título de seção
- [ ] Campo com ícone/botão colado (ex.: campo + botão de copiar)
- [ ] Formulário em etapas (assistente/wizard) vs formulário numa página só

---

## 4. Listas e coleções

### 4.1 Estrutura da linha

- [ ] Lista simples, só texto
- [ ] Lista com ícone à esquerda
- [ ] Lista com avatar/imagem à esquerda
- [ ] Lista de duas linhas (título em cima, descrição menor embaixo)
- [ ] Lista com elemento à direita (ícone, botão, alternador, valor)
- [ ] Lista com linha divisória entre itens
- [ ] Lista sem divisória, só espaço
- [ ] Lista com fundo alternado (zebra, linha sim/linha não)
- [ ] Densidade compacta vs confortável da lista

### 4.2 Comportamento

- [ ] Lista clicável (linha inteira leva a algum lugar)
- [ ] Lista com seleção múltipla (checkbox em cada linha)
- [ ] Lista com ação ao passar o mouse (botões que aparecem só no hover)
- [ ] Lista com ação de deslizar (swipe, em toque/celular)
- [ ] Lista arrastável pra reordenar
- [ ] Lista aninhada/em árvore (itens dentro de itens, com recuo)
- [ ] Lista expansível (accordion: clica e abre o conteúdo de dentro)
- [ ] Lista com rolagem infinita (carrega mais ao chegar no fim)
- [ ] Lista com paginação numerada
- [ ] Lista com botão "carregar mais"
- [ ] Lista virtualizada (só renderiza o que está visível, pra listas gigantes)

### 4.3 Estados especiais da lista

- [ ] Lista vazia (o que aparece quando não tem nenhum item, com texto e ação sugerida)
- [ ] Lista carregando (esqueleto de linhas cinzas piscando, no lugar do conteúdo real)
- [ ] Lista com erro ao carregar

---

## 5. Cards e superfícies

- [ ] Card plano (sem sombra, só um fundo diferente)
- [ ] Card com sombra
- [ ] Card com borda visível
- [ ] Card clicável (muda ao passar o mouse: sombra cresce, ou levanta um pouco)
- [ ] Card com imagem no topo, texto embaixo
- [ ] Card com imagem do lado, texto ao lado (horizontal)
- [ ] Card com cabeçalho e rodapé separados por linha
- [ ] Card destacado (borda ou faixa colorida, pra chamar atenção especial)
- [ ] Card desabilitado/apagado
- [ ] Painel/seção (bloco maior que agrupa vários cards ou campos)
- [ ] Divisor simples (linha horizontal que separa duas partes de uma tela)

---

## 6. Navegação

- [ ] Barra superior (topo da tela, marca + ações gerais)
- [ ] Barra lateral fixa
- [ ] Barra lateral que recolhe/expande
- [ ] Barra lateral com submenus (itens que abrem outros itens dentro)
- [ ] Abas (tabs) horizontais
- [ ] Abas verticais
- [ ] Trilha de navegação (breadcrumb: "Início > Seção > Página atual")
- [ ] Paginação numerada (1, 2, 3...)
- [ ] Paginação simples (anterior / próximo)
- [ ] Indicador de progresso em etapas (stepper: passo 1 de 4)
- [ ] Menu suspenso ao clicar (dropdown)
- [ ] Menu de contexto (aparece ao clicar com o botão direito ou segurar)
- [ ] Barra de navegação inferior (uso em celular)
- [ ] Atalho de teclado documentado (e como ele aparece visualmente, tipo "Ctrl+K")
- [ ] Indicador de "você está aqui" (item ativo destacado no menu)

---

## 7. Overlays e feedback (o que aparece por cima da tela)

### 7.1 Janelas e painéis

- [ ] Modal pequeno (confirmação simples)
- [ ] Modal médio (formulário curto)
- [ ] Modal grande / tela cheia
- [ ] Painel lateral (drawer, desliza da borda da tela)
- [ ] Popover (caixinha pequena perto de um elemento, tipo calendário ao clicar num campo de data)
- [ ] Tooltip (dica curta que aparece ao passar o mouse)

### 7.2 Avisos e notificações

- [ ] Notificação temporária (toast/snackbar) no canto da tela
- [ ] Notificação temporária no topo
- [ ] Notificação com botão de ação ("Desfazer")
- [ ] Notificação com barra de tempo até sumir sozinha
- [ ] Banner de aviso fixo no topo da página (não some sozinho)
- [ ] Alerta inline dentro de uma seção (não é notificação solta, é parte do conteúdo)
- [ ] Confirmação de ação destrutiva (double-check: "tem certeza que quer apagar?")

### 7.3 Carregamento e progresso

- [ ] Giro de carregamento (spinner) pequeno
- [ ] Giro de carregamento grande, de página inteira
- [ ] Barra de progresso linear (mostra 0 a 100%)
- [ ] Barra de progresso circular
- [ ] Esqueleto de carregamento (skeleton: blocos cinza piscando no formato do conteúdo real)
- [ ] Indicador de progresso indeterminado (não sabe quanto falta, só mostra "está acontecendo")

### 7.4 Estados vazios e de erro

- [ ] Estado vazio (nada a mostrar): ilustração ou ícone + texto explicando + botão de ação
- [ ] Estado de erro (algo quebrou): o que mostrar, e se tem botão de tentar de novo
- [ ] Estado de "sem permissão"/acesso negado

---

## 8. Exibição de dados

### 8.1 Tabela

- [ ] Tabela simples
- [ ] Tabela com cabeçalho fixo (não rola junto com o conteúdo)
- [ ] Tabela com coluna ordenável (clica no título, ordena)
- [ ] Tabela com filtro por coluna
- [ ] Tabela com seleção de linha (checkbox)
- [ ] Tabela com ação por linha (menu de três pontinhos, ou botões)
- [ ] Tabela com linha de totais/resumo no fim
- [ ] Tabela densa vs tabela espaçosa
- [ ] Tabela que vira lista de cards em tela pequena (celular)

### 8.2 Rótulos e indicadores pequenos

- [ ] Badge/etiqueta simples (só texto numa caixinha colorida)
- [ ] Badge com ícone
- [ ] Badge numérico (contador, tipo "5 notificações")
- [ ] Chip removível (com um "x" pra tirar, comum em filtro ativo)
- [ ] Indicador de status (bolinha colorida: online, ativo, pendente, etc, com legenda ao lado)

### 8.3 Pessoas e identidade

- [ ] Avatar com foto
- [ ] Avatar com iniciais (quando não tem foto)
- [ ] Avatar com ícone genérico (quando não tem nem nome)
- [ ] Avatar com indicador de status (bolinha de online/ausente no canto)
- [ ] Grupo de avatares sobrepostos (mostrar várias pessoas num espaço pequeno)

### 8.4 Números e gráficos

- [ ] Número grande de destaque com legenda embaixo (KPI/estatística)
- [ ] Gráfico de barras
- [ ] Gráfico de linha
- [ ] Gráfico de pizza ou rosca
- [ ] Gráfico de área
- [ ] Mini-gráfico de linha simples (sparkline, sem eixo, só a tendência)
- [ ] Linha do tempo (timeline: eventos em ordem, com data)

---

## 9. Mídia

- [ ] Imagem com proporção fixa (não deforma ao redimensionar)
- [ ] Imagem com cantos arredondados
- [ ] Imagem com moldura/borda
- [ ] Espaço reservado (placeholder) enquanto a imagem carrega
- [ ] Imagem que amplia ao clicar (zoom)
- [ ] Player de vídeo com controles
- [ ] Miniatura de vídeo com botão de play por cima
- [ ] Galeria/carrossel de várias imagens

---

## 10. Estados de interação (valem pra quase todo elemento clicável)

- [ ] Repouso (nada acontecendo)
- [ ] Hover (mouse em cima)
- [ ] Foco por teclado (navegando sem mouse)
- [ ] Pressionado/ativo (no instante do clique ou toque)
- [ ] Selecionado (marcado, faz parte de um grupo escolhido)
- [ ] Desabilitado
- [ ] Carregando
- [ ] Erro
- [ ] Sucesso
- [ ] Arrastando (o próprio elemento sendo movido)
- [ ] Área de destino ao arrastar por cima (drag-over: onde vai soltar)

---

## 11. Movimento e transições (catálogo de efeitos)

- [ ] Esmaecer (fade: aparece/some suavemente)
- [ ] Deslizar (slide: entra vindo de um lado)
- [ ] Escalar (scale: cresce ao aparecer, encolhe ao sumir)
- [ ] Girar (rotate: usado em ícone de carregamento, seta de expandir)
- [ ] Revelar (reveal: um painel se abre mostrando o que tinha escondido)
- [ ] Transição ao trocar de página inteira
- [ ] Microinteração de clique (o botão "aperta" visualmente)
- [ ] Microinteração de confirmação (ícone de check desenhando)
- [ ] Efeito cascata em lista (stagger: os itens aparecem um após o outro, não todos juntos)
- [ ] Brilho passando (shimmer) no esqueleto de carregamento
- [ ] Transição suave ao trocar de aba
- [ ] Animação de arrastar (o item segue o dedo/mouse com uma leve sombra extra)

---

## 12. Layout e responsividade

- [ ] Como o layout se comporta em celular (uma coluna, menu vira gaveta, etc.)
- [ ] Como se comporta em tablet
- [ ] Como se comporta em tela grande/desktop
- [ ] Como se comporta em tela muito larga (ultrawide): estica o conteúdo ou mantém largura máxima
- [ ] Comportamento em orientação retrato vs paisagem (celular/tablet)
- [ ] Tamanho mínimo de área clicável em toque (dedo, não mouse)

---

## 13. Temas

- [ ] Tema claro
- [ ] Tema escuro
- [ ] Tema de alto contraste (acessibilidade)
- [ ] Se existe mais de uma "marca"/empresa dentro do mesmo sistema, tema próprio pra cada uma
- [ ] Alternância manual entre temas (botão) vs seguir automaticamente a preferência do aparelho

---

## 14. Acessibilidade

- [ ] Contraste mínimo de texto sobre fundo, testado em cada combinação de cor
- [ ] Foco visível sempre, em todo elemento navegável por teclado
- [ ] Tamanho mínimo de área de toque/clique
- [ ] Texto alternativo em toda imagem que carrega informação
- [ ] Navegação completa só de teclado (sem precisar do mouse em nenhum momento)
- [ ] Leitura por leitor de tela (nomes e papéis dos elementos fazem sentido quando lidos em voz alta)
- [ ] Respeito à preferência de "reduzir movimento" do sistema operacional

---

## 15. Conteúdo e voz (o que o sistema "fala")

- [ ] Tom de voz (formal, direto, próximo) e se muda entre público interno e cliente externo
- [ ] Como uma ação é nomeada (o rótulo do botão diz exatamente o que vai acontecer)
- [ ] Como um erro é explicado (o que deu errado + como resolver, sem jargão)
- [ ] Texto de confirmação depois de uma ação bem-sucedida
- [ ] Texto de estado vazio (o que dizer quando não tem nada ali ainda)
- [ ] Maiúsculas/minúsculas em título de botão e de tela (padrão a seguir sempre)

---

## Anexo: perguntas guia pra levar ao agente de design

Pra cada seção acima, ao decidir com o agente, vale registrar:

1. Qual variante da lista a gente escolhe (ou quais, se mais de uma for usada em contextos diferentes)?
2. O valor exato (cor em hexadecimal, medida em pixels, nome da fonte, duração em milissegundos)?
3. Em que situação do sistema esse item aparece (dar pelo menos um exemplo real de tela)?
4. Isso muda entre tema claro e escuro? Como?
5. Isso muda entre tipo de usuário (cliente, colaborador, gerente, diretor, CEO) ou entre empresa do grupo?

O resultado dessas perguntas, respondidas item por item, é o próprio documento de identidade visual novo.
